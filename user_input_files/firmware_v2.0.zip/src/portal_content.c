/**
 * Portal Content Manager Implementation
 *
 * Manages custom HTML content storage and retrieval for the captive portal.
 * Supports receiving content via BLE chunked transfer and storing in NVS flash.
 *
 * Architecture:
 * - Dual buffer system: working buffer for transfer, NVS for persistence
 * - CRC32 validation ensures data integrity
 * - Graceful fallback to default content on errors
 *
 * Author: MiniMax Agent
 * Version: 2.0.0
 */

#include "portal_content.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_partition.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "string.h"
#include "stdlib.h"
#include "stdio.h"
#include "crc.h"

static const char* TAG = "PORTAL_CONTENT";

/* Static configuration */
#define PORTAL_NVS_NAMESPACE         "portal"

/* Default portal content - shown when no custom content is loaded */
static const char DEFAULT_HTML[] =
    "<!DOCTYPE html>"
    "<html>"
    "<head>"
    "<meta charset=\"UTF-8\">"
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
    "<title>PromoBeacon</title>"
    "<style>"
    "body { font-family: Arial, sans-serif; text-align: center; padding: 50px; "
           "background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); "
           "min-height: 100vh; margin: 0; display: flex; flex-direction: column; "
           "justify-content: center; align-items: center; }"
    ".container { background: white; padding: 40px; border-radius: 20px; "
                 "box-shadow: 0 10px 40px rgba(0,0,0,0.2); max-width: 500px; width: 90%%; }"
    "h1 { color: #333; margin-bottom: 20px; font-size: 2em; }"
    ".message { font-size: 1.5em; color: #0061A4; font-weight: bold; "
               "margin: 30px 0; padding: 20px; background: #f5f5f5; border-radius: 10px; }"
    ".footer { margin-top: 30px; color: #666; font-size: 0.9em; }"
    "</style>"
    "</head>"
    "<body>"
    "<div class=\"container\">"
    "<h1>Welcome</h1>"
    "<div class=\"message\">%s</div>"
    "<div class=\"footer\">Powered by PromoBeacon</div>"
    "</div>"
    "</body>"
    "</html>";

/* Static buffers and state */
static uint8_t* g_content_buffer = NULL;       /* Working buffer for content */
static uint32_t g_content_size = 0;            /* Current content size */
static uint32_t g_allocated_size = 0;          /* Allocated buffer size */

static portal_transfer_state_t g_transfer = {0}; /* Transfer state */
static bool g_initialized = false;              /* Initialization flag */
static bool g_is_custom = false;                /* Using custom content */

/* ============================================================================
 * CRC32 IMPLEMENTATION
 * ============================================================================ */

/**
 * @brief Calculate CRC32 for data integrity
 */
static uint32_t calculate_crc32(const void* data, size_t length)
{
    uint32_t crc = 0xFFFFFFFF;
    const uint8_t* bytes = (const uint8_t*)data;

    for (size_t i = 0; i < length; i++) {
        crc ^= bytes[i];
        for (int j = 0; j < 8; j++) {
            crc = (crc >> 1) ^ (0xEDB88320 & -(crc & 1));
        }
    }

    return crc ^ 0xFFFFFFFF;
}

/* ============================================================================
 * NVS OPERATIONS
 * ============================================================================ */

/**
 * @brief Save content to NVS flash
 */
esp_err_t portal_save_to_nvs(void)
{
    if (g_content_buffer == NULL || g_content_size == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    nvs_handle_t nvs_handle;
    esp_err_t ret = nvs_open(PORTAL_NVS_NAMESPACE, NVS_READWRITE, &nvs_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to open NVS: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Calculate and store CRC */
    uint32_t crc = calculate_crc32(g_content_buffer, g_content_size);

    ret = nvs_set_blob(nvs_handle, PORTAL_NVS_CONTENT_KEY, g_content_buffer, g_content_size);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to write content: %s", esp_err_to_name(ret));
        nvs_close(nvs_handle);
        return ret;
    }

    ret = nvs_set_u32(nvs_handle, PORTAL_NVS_SIZE_KEY, g_content_size);
    if (ret != ESP_OK) {
        nvs_close(nvs_handle);
        return ret;
    }

    ret = nvs_set_u32(nvs_handle, PORTAL_NVS_CRC_KEY, crc);
    if (ret != ESP_OK) {
        nvs_close(nvs_handle);
        return ret;
    }

    ret = nvs_commit(nvs_handle);
    nvs_close(nvs_handle);

    if (ret == ESP_OK) {
        g_is_custom = true;
        ESP_LOGI(TAG, "Content saved to NVS: %u bytes, CRC=0x%08X", g_content_size, crc);
    }

    return ret;
}

/**
 * @brief Load content from NVS flash
 */
esp_err_t portal_load_from_nvs(void)
{
    nvs_handle_t nvs_handle;
    esp_err_t ret = nvs_open(PORTAL_NVS_NAMESPACE, NVS_READONLY, &nvs_handle);
    if (ret != ESP_OK) {
        ESP_LOGI(TAG, "No NVS content found, using default");
        g_is_custom = false;
        return ESP_ERR_NVS_NOT_FOUND;
    }

    /* Get content size */
    uint32_t size;
    ret = nvs_get_u32(nvs_handle, PORTAL_NVS_SIZE_KEY, &size);
    if (ret != ESP_OK || size == 0 || size > PORTAL_MAX_SIZE) {
        ESP_LOGW(TAG, "Invalid content size in NVS");
        nvs_close(nvs_handle);
        g_is_custom = false;
        return ESP_ERR_INVALID_SIZE;
    }

    /* Allocate buffer if needed */
    if (g_allocated_size < size) {
        if (g_content_buffer) {
            free(g_content_buffer);
        }
        g_content_buffer = (uint8_t*)malloc(size + 1);
        if (g_content_buffer == NULL) {
            ESP_LOGE(TAG, "Failed to allocate buffer for NVS content");
            nvs_close(nvs_handle);
            return ESP_ERR_NO_MEM;
        }
        g_allocated_size = size + 1;
    }

    /* Read content */
    size_t read_size = size;
    ret = nvs_get_blob(nvs_handle, PORTAL_NVS_CONTENT_KEY, g_content_buffer, &read_size);
    if (ret != ESP_OK || read_size != size) {
        ESP_LOGE(TAG, "Failed to read content: %s", esp_err_to_name(ret));
        nvs_close(nvs_handle);
        return ret;
    }

    /* Verify CRC */
    uint32_t stored_crc;
    ret = nvs_get_u32(nvs_handle, PORTAL_NVS_CRC_KEY, &stored_crc);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "No CRC found, skipping validation");
    } else {
        uint32_t calculated_crc = calculate_crc32(g_content_buffer, size);
        if (calculated_crc != stored_crc) {
            ESP_LOGE(TAG, "CRC mismatch: stored=0x%08X, calculated=0x%08X",
                     stored_crc, calculated_crc);
            nvs_close(nvs_handle);
            /* Try to recover by clearing invalid content */
            nvs_open(PORTAL_NVS_NAMESPACE, NVS_READWRITE, &nvs_handle);
            nvs_erase_key(nvs_handle, PORTAL_NVS_CONTENT_KEY);
            nvs_commit(nvs_handle);
            nvs_close(nvs_handle);
            g_is_custom = false;
            return ESP_ERR_INVALID_CRC;
        }
    }

    nvs_close(nvs_handle);

    g_content_buffer[size] = '\0';
    g_content_size = size;

    ESP_LOGI(TAG, "Loaded content from NVS: %u bytes", g_content_size);
    g_is_custom = true;

    return ESP_OK;
}

/**
 * @brief Delete custom content from NVS
 */
esp_err_t portal_delete_custom_content(void)
{
    nvs_handle_t nvs_handle;
    esp_err_t ret = nvs_open(PORTAL_NVS_NAMESPACE, NVS_READWRITE, &nvs_handle);
    if (ret != ESP_OK) {
        return ret;
    }

    ret = nvs_erase_key(nvs_handle, PORTAL_NVS_CONTENT_KEY);
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NOT_FOUND) {
        nvs_close(nvs_handle);
        return ret;
    }

    ret = nvs_erase_key(nvs_handle, PORTAL_NVS_SIZE_KEY);
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NOT_FOUND) {
        nvs_close(nvs_handle);
        return ret;
    }

    ret = nvs_erase_key(nvs_handle, PORTAL_NVS_CRC_KEY);
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NOT_FOUND) {
        nvs_close(nvs_handle);
        return ret;
    }

    ret = nvs_commit(nvs_handle);
    nvs_close(nvs_handle);

    if (ret == ESP_OK) {
        g_is_custom = false;
        ESP_LOGI(TAG, "Custom content deleted from NVS");
    }

    return ret;
}

/* ============================================================================
 * TRANSFER OPERATIONS
 * ============================================================================ */

/**
 * @brief Start portal content transfer
 */
esp_err_t portal_transfer_start(uint32_t total_size, uint32_t crc32)
{
    if (total_size == 0 || total_size > PORTAL_MAX_SIZE) {
        ESP_LOGE(TAG, "Invalid transfer size: %lu", (unsigned long)total_size);
        return ESP_ERR_INVALID_SIZE;
    }

    /* Abort any existing transfer */
    portal_transfer_abort();

    /* Allocate buffer */
    g_content_buffer = (uint8_t*)malloc(total_size + 1);
    if (g_content_buffer == NULL) {
        ESP_LOGE(TAG, "Failed to allocate transfer buffer: %lu bytes", (unsigned long)total_size);
        return ESP_ERR_NO_MEM;
    }

    memset(g_content_buffer, 0, total_size + 1);
    g_allocated_size = total_size + 1;
    g_content_size = 0;

    /* Initialize transfer state */
    g_transfer.status = PORTAL_STATUS_RECEIVING;
    g_transfer.total_size = total_size;
    g_transfer.bytes_received = 0;
    g_transfer.expected_seq = 0;
    g_transfer.crc32 = crc32;
    g_transfer.buffer = g_content_buffer;

    ESP_LOGI(TAG, "Transfer started: %lu bytes, CRC=0x%08X",
             (unsigned long)total_size, crc32);

    return ESP_OK;
}

/**
 * @brief Process received data chunk
 */
esp_err_t portal_transfer_process_chunk(uint16_t seq_num, const uint8_t* data, uint16_t data_len)
{
    if (g_transfer.status != PORTAL_STATUS_RECEIVING) {
        ESP_LOGE(TAG, "Not in receiving state");
        return ESP_ERR_INVALID_STATE;
    }

    if (g_content_buffer == NULL) {
        ESP_LOGE(TAG, "No transfer buffer");
        return ESP_ERR_INVALID_STATE;
    }

    /* Check sequence number */
    if (seq_num != g_transfer.expected_seq) {
        ESP_LOGW(TAG, "Sequence mismatch: expected=%u, received=%u",
                 g_transfer.expected_seq, seq_num);
        /* Continue anyway - we might still recover */
    }

    /* Check bounds */
    if (g_transfer.bytes_received + data_len > g_transfer.total_size) {
        ESP_LOGE(TAG, "Buffer overflow: %lu + %u > %lu",
                 (unsigned long)g_transfer.bytes_received, data_len,
                 (unsigned long)g_transfer.total_size);
        portal_transfer_abort();
        return ESP_ERR_INVALID_SIZE;
    }

    /* Copy data to buffer */
    memcpy(g_content_buffer + g_transfer.bytes_received, data, data_len);
    g_transfer.bytes_received += data_len;
    g_transfer.expected_seq++;

    ESP_LOGD(TAG, "Chunk %u: %u bytes, total: %lu / %lu",
             seq_num, data_len,
             (unsigned long)g_transfer.bytes_received,
             (unsigned long)g_transfer.total_size);

    return ESP_OK;
}

/**
 * @brief Complete portal content transfer
 */
esp_err_t portal_transfer_complete(void)
{
    if (g_transfer.status != PORTAL_STATUS_RECEIVING) {
        return ESP_ERR_INVALID_STATE;
    }

    /* Verify we received all bytes */
    if (g_transfer.bytes_received != g_transfer.total_size) {
        ESP_LOGE(TAG, "Incomplete transfer: %lu / %lu",
                 (unsigned long)g_transfer.bytes_received,
                 (unsigned long)g_transfer.total_size);
        portal_transfer_abort();
        return ESP_ERR_INVALID_SIZE;
    }

    /* Verify CRC */
    uint32_t calculated_crc = calculate_crc32(g_content_buffer, g_content_size);
    if (calculated_crc != g_transfer.crc32) {
        ESP_LOGE(TAG, "CRC mismatch: expected=0x%08X, calculated=0x%08X",
                 g_transfer.crc32, calculated_crc);
        portal_transfer_abort();
        return ESP_ERR_INVALID_CRC;
    }

    /* Null terminate */
    g_content_buffer[g_content_size] = '\0';

    /* Save to NVS */
    esp_err_t ret = portal_save_to_nvs();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to save to NVS: %s", esp_err_to_name(ret));
        portal_transfer_abort();
        return ret;
    }

    g_transfer.status = PORTAL_STATUS_COMPLETE;

    ESP_LOGI(TAG, "Transfer complete: %u bytes saved to NVS", g_content_size);

    return ESP_OK;
}

/**
 * @brief Abort portal content transfer
 */
void portal_transfer_abort(void)
{
    if (g_transfer.buffer) {
        free(g_transfer.buffer);
        g_transfer.buffer = NULL;
    }

    memset(&g_transfer, 0, sizeof(portal_transfer_state_t));
    g_transfer.status = PORTAL_STATUS_IDLE;

    /* Don't free main content buffer - keep it for fallback */
    ESP_LOGI(TAG, "Transfer aborted");
}

/**
 * @brief Get current transfer status
 */
esp_err_t portal_transfer_get_status(uint8_t* status, uint8_t* progress)
{
    if (!status || !progress) {
        return ESP_ERR_INVALID_ARG;
    }

    *status = g_transfer.status;

    if (g_transfer.status == PORTAL_STATUS_RECEIVING && g_transfer.total_size > 0) {
        *progress = (uint8_t)((g_transfer.bytes_received * 100) / g_transfer.total_size);
    } else {
        *progress = 0;
    }

    return ESP_OK;
}

/* ============================================================================
 * CONTENT MANAGEMENT
 * ============================================================================ */

/**
 * @brief Initialize portal content manager
 */
esp_err_t portal_content_init(void)
{
    if (g_initialized) {
        ESP_LOGW(TAG, "Already initialized");
        return ESP_OK;
    }

    ESP_LOGI(TAG, "Initializing portal content manager");

    /* Initialize transfer state */
    memset(&g_transfer, 0, sizeof(portal_transfer_state_t));
    g_transfer.status = PORTAL_STATUS_IDLE;

    /* Try to load custom content from NVS */
    esp_err_t ret = portal_load_from_nvs();
    if (ret != ESP_OK) {
        /* Use default content - pointer to default HTML */
        g_content_buffer = NULL;
        g_content_size = 0;
        g_is_custom = false;
    }

    g_initialized = true;

    ESP_LOGI(TAG, "Portal content manager initialized, custom=%s",
             g_is_custom ? "yes" : "no");

    return ESP_OK;
}

/**
 * @brief Deinitialize portal content manager
 */
void portal_content_deinit(void)
{
    if (!g_initialized) {
        return;
    }

    ESP_LOGI(TAG, "Deinitializing portal content manager");

    /* Abort any ongoing transfer */
    portal_transfer_abort();

    /* Free content buffer if allocated */
    if (g_content_buffer && !g_is_custom) {
        /* Buffer was from NVS load, should keep it */
    }

    g_content_buffer = NULL;
    g_content_size = 0;
    g_allocated_size = 0;
    g_is_custom = false;

    g_initialized = false;

    ESP_LOGI(TAG, "Portal content manager deinitialized");
}

/**
 * @brief Get portal content for serving
 */
const char* portal_content_get(void)
{
    if (g_content_buffer && g_content_size > 0) {
        return (const char*)g_content_buffer;
    }

    /* Return NULL when no custom content - web server should use default */
    return NULL;
}

/**
 * @brief Get portal content size
 */
size_t portal_content_get_size(void)
{
    return g_content_size;
}

/**
 * @brief Check if custom content is loaded
 */
bool portal_content_is_custom(void)
{
    return g_is_custom;
}

/**
 * @brief Get portal content information
 */
esp_err_t portal_get_info(portal_content_info_t* info)
{
    if (!info) {
        return ESP_ERR_INVALID_ARG;
    }

    info->size = g_content_size;
    info->valid = (g_content_buffer != NULL && g_content_size > 0);
    info->exists = g_is_custom;

    if (info->valid && info->exists) {
        info->crc32 = calculate_crc32(g_content_buffer, g_content_size);
    } else {
        info->crc32 = 0;
    }

    return ESP_OK;
}

/**
 * @brief Reset to default content
 */
esp_err_t portal_reset_to_default(void)
{
    esp_err_t ret = portal_delete_custom_content();

    /* Free custom content buffer if loaded */
    if (g_content_buffer && g_is_custom) {
        free(g_content_buffer);
        g_content_buffer = NULL;
    }

    g_content_size = 0;
    g_is_custom = false;

    return ret;
}

/**
 * @brief Validate content CRC32
 */
bool portal_validate_crc(uint32_t expected_crc)
{
    if (g_content_buffer == NULL || g_content_size == 0) {
        return false;
    }

    uint32_t calculated = calculate_crc32(g_content_buffer, g_content_size);
    return (calculated == expected_crc);
}

/**
 * @brief Calculate CRC32 of content
 */
uint32_t portal_calculate_crc(void)
{
    if (g_content_buffer == NULL || g_content_size == 0) {
        return 0;
    }

    return calculate_crc32(g_content_buffer, g_content_size);
}

/**
 * @brief Send transfer status notification (stub for BLE integration)
 */
void portal_notify_status(uint8_t status, uint8_t progress)
{
    /* This will be called by ble_manager when we integrate */
    ESP_LOGD(TAG, "Status notification: status=%u, progress=%u%%", status, progress);
}

/**
 * @brief Get default HTML with promo text substituted
 */
const char* portal_get_default_html(const char* promo_text)
{
    static char default_buffer[2048];
    static const char* cached_promo = NULL;
    static bool cache_valid = false;

    /* Rebuild if promo text changed */
    if (!cache_valid || cached_promo != promo_text) {
        const char* text = promo_text ? promo_text : "Welcome!";
        snprintf(default_buffer, sizeof(default_buffer), DEFAULT_HTML, text);
        cached_promo = promo_text;
        cache_valid = true;
    }

    return default_buffer;
}

/**
 * @brief Get default HTML with promo text and device ID
 */
const char* portal_get_default_html_with_id(const char* promo_text, const char* device_id)
{
    static char default_buffer[2048];
    static const char* cached_promo = NULL;
    static const char* cached_id = NULL;
    static bool cache_valid = false;

    /* Rebuild if promo text or device ID changed */
    if (!cache_valid || cached_promo != promo_text || cached_id != device_id) {
        const char* text = promo_text ? promo_text : "Welcome!";
        const char* id = device_id ? device_id : "PB-UNKNOWN";

        /* Generate HTML with device ID in corner */
        snprintf(default_buffer, sizeof(default_buffer),
            "<!DOCTYPE html>"
            "<html>"
            "<head>"
            "<meta charset=\"UTF-8\">"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
            "<title>%s</title>"
            "<style>"
            "body { font-family: Arial, sans-serif; margin: 0; padding: 20px; "
            "background: linear-gradient(135deg, #667eea 0%%, #764ba2 100%%); "
            "min-height: 100vh; display: flex; align-items: center; justify-content: center; }"
            ".container { background: white; padding: 40px; border-radius: 20px; "
            "box-shadow: 0 10px 40px rgba(0,0,0,0.2); text-align: center; max-width: 500px; }"
            "h1 { color: #333; font-size: 32px; margin: 0 0 20px; }"
            "p { color: #666; font-size: 18px; }"
            ".device-id { position: fixed; bottom: 10px; right: 10px; "
            "color: rgba(255,255,255,0.5); font-size: 12px; font-family: monospace; }"
            "</style>"
            "</head>"
            "<body>"
            "<div class=\"container\">"
            "<h1>%s</h1>"
            "<p>Welcome to our promotion!</p>"
            "</div>"
            "<div class=\"device-id\">%s</div>"
            "</body>"
            "</html>",
            text, text, id);

        cached_promo = promo_text;
        cached_id = device_id;
        cache_valid = true;
    }

    return default_buffer;
}
