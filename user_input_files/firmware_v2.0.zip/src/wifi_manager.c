/**
 * WiFi Manager Implementation
 * 
 * Manages WiFi Access Point configuration and DNS server
 * for the captive portal functionality.
 */

#include "wifi_manager.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "tcpip_adapter.h"
#include "lwip/sockets.h"
#include "lwip/netdb.h"
#include "string.h"

static const char* TAG = "WIFI_MGR";

/* WiFi AP state */
static bool wifi_ap_active = false;
static bool dns_server_active = false;
static char ap_ssid[MAX_SSID_LENGTH + 1] = {0};
static char ap_password[MAX_PASSWORD_LENGTH + 1] = {0};
static bool encryption_enabled = false;

/* DNS server state */
static int dns_socket = -1;
static struct sockaddr_in dns_server_addr;
static ip4_addr_t ap_ip_addr;

/* Client tracking */
static uint8_t client_count = 0;

/**
 * @brief WiFi event handler
 */
static void wifi_event_handler(void* arg, esp_event_base_t event_base,
                               int32_t event_id, void* event_data)
{
    if (event_base == WIFI_EVENT) {
        switch (event_id) {
            case WIFI_EVENT_AP_STACONNECTED:
                wifi_event_ap_staconnected_t* conn = 
                    (wifi_event_ap_staconnected_t*)event_data;
                client_count++;
                ESP_LOGI(TAG, "Station connected: AID=%d, MAC=" MACSTR,
                         conn->aid, MAC2STR(conn->mac));
                break;
                
            case WIFI_EVENT_AP_STADISCONNECTED:
                wifi_event_ap_stadisconnected_t* disconn = 
                    (wifi_event_ap_stadisconnected_t*)event_data;
                
                /* Send deauthentication frame to force client to forget network */
                /* This prevents automatic reconnection */
                ESP_LOGI(TAG, "Sending deauth to station: MAC=" MACSTR,
                         MAC2STR(disconn->mac));
                esp_wifi_deauth_sta(disconn->mac);
                
                if (client_count > 0) client_count--;
                ESP_LOGI(TAG, "Station disconnected: AID=%d, MAC=" MACSTR,
                         disconn->aid, MAC2STR(disconn->mac));
                break;
                
            default:
                break;
        }
    }
}

esp_err_t init_wifi_ap(const char* ssid, const char* password)
{
    esp_err_t ret;
    
    if (wifi_ap_active) {
        ESP_LOGW(TAG, "WiFi AP already active");
        return ESP_OK;
    }
    
    if (!ssid || strlen(ssid) == 0) {
        ESP_LOGE(TAG, "Invalid SSID");
        return ESP_ERR_INVALID_ARG;
    }
    
    ESP_LOGI(TAG, "Initializing WiFi AP: %s", ssid);
    
    /* Store configuration */
    strncpy(ap_ssid, ssid, MAX_SSID_LENGTH);
    ap_ssid[MAX_SSID_LENGTH] = '\0';
    
    if (password && strlen(password) >= 8) {
        strncpy(ap_password, password, MAX_PASSWORD_LENGTH);
        ap_password[MAX_PASSWORD_LENGTH] = '\0';
        encryption_enabled = true;
    } else {
        ap_password[0] = '\0';
        encryption_enabled = false;
    }
    
    /* Initialize WiFi */
    wifi_init_config_t init_config = WIFI_INIT_CONFIG_DEFAULT();
    ret = esp_wifi_init(&init_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi init failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    /* Register event handler */
    ret = esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, 
                                     &wifi_event_handler, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Event handler registration failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    /* Configure WiFi */
    wifi_config_t wifi_config = {
        .ap = {
            .ssid = "",
            .ssid_len = 0,
            .channel = DEFAULT_AP_CHANNEL,
            .authmode = encryption_enabled ? WIFI_AUTH_WPA2_PSK : WIFI_AUTH_OPEN,
            .max_connection = MAX_CLIENT_CONNECTIONS,
            .beacon_interval = DEFAULT_BEACON_INTERVAL,
        },
    };
    
    memcpy(wifi_config.ap.ssid, ap_ssid, strlen(ap_ssid));
    wifi_config.ap.ssid_len = strlen(ap_ssid);
    
    if (encryption_enabled) {
        memcpy(wifi_config.ap.password, ap_password, strlen(ap_password));
    }
    
    /* Set WiFi mode to AP */
    ret = esp_wifi_set_mode(WIFI_MODE_AP);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi mode set failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    /* Apply configuration */
    ret = esp_wifi_set_config(WIFI_IF_AP, &wifi_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi config set failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    /* Start WiFi */
    ret = esp_wifi_start();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi start failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    /* Configure IP address */
    tcpip_adapter_ip_info_t ip_info = {
        .ip = {.addr = IP4ADDR_AP},
        .gw = {.addr = IP4ADDR_AP},
        .netmask = {.addr = IP4ADDR_NETMASK},
    };
    
    ret = tcpip_adapter_set_ap_ip_info(TCPIP_ADAPTER_IF_AP, &ip_info);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "IP info set failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    /* Store AP IP address for DNS server */
    ap_ip_addr.addr = ip_info.ip.addr;
    
    /* Start DHCP server */
    tcpip_adapter_dhcp_status_t dhcp_status;
    tcpip_adapter_dhcp_start(TCPIP_ADAPTER_IF_AP);
    
    wifi_ap_active = true;
    client_count = 0;
    
    ESP_LOGI(TAG, "WiFi AP started: %s (%s)", ap_ssid, 
             encryption_enabled ? "WPA2" : "OPEN");
    ESP_LOGI(TAG, "AP IP: " IPSTR, IP2STR(&ip_info.ip));
    
    return ESP_OK;
}

void stop_wifi_ap(void)
{
    if (!wifi_ap_active) {
        return;
    }
    
    ESP_LOGI(TAG, "Stopping WiFi AP");
    
    /* Stop DHCP server */
    tcpip_adapter_dhcp_stop(TCPIP_ADAPTER_IF_AP);
    
    /* Stop WiFi */
    esp_wifi_stop();
    esp_wifi_deinit();
    
    /* Unregister event handler */
    esp_event_handler_unregister(WIFI_EVENT, ESP_EVENT_ANY_ID, 
                                 &wifi_event_handler);
    
    wifi_ap_active = false;
    client_count = 0;
    
    ESP_LOGI(TAG, "WiFi AP stopped");
}

esp_err_t update_ap_ssid(const char* new_ssid)
{
    if (!wifi_ap_active) {
        return ESP_ERR_INVALID_STATE;
    }
    
    if (!new_ssid || strlen(new_ssid) == 0 || strlen(new_ssid) > MAX_SSID_LENGTH) {
        return ESP_ERR_INVALID_ARG;
    }
    
    strncpy(ap_ssid, new_ssid, MAX_SSID_LENGTH);
    ap_ssid[MAX_SSID_LENGTH] = '\0';
    
    wifi_config_t wifi_config = {0};
    esp_wifi_get_config(WIFI_IF_AP, &wifi_config);
    
    memcpy(wifi_config.ap.ssid, ap_ssid, strlen(ap_ssid));
    wifi_config.ap.ssid_len = strlen(ap_ssid);
    
    esp_err_t ret = esp_wifi_set_config(WIFI_IF_AP, &wifi_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "SSID update failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    ESP_LOGI(TAG, "AP SSID updated: %s", ap_ssid);
    
    return ESP_OK;
}

esp_err_t update_ap_password(const char* new_password)
{
    if (!wifi_ap_active) {
        return ESP_ERR_INVALID_STATE;
    }
    
    wifi_config_t wifi_config = {0};
    esp_wifi_get_config(WIFI_IF_AP, &wifi_config);
    
    if (new_password && strlen(new_password) >= 8) {
        strncpy(ap_password, new_password, MAX_PASSWORD_LENGTH);
        ap_password[MAX_PASSWORD_LENGTH] = '\0';
        encryption_enabled = true;
        wifi_config.ap.authmode = WIFI_AUTH_WPA2_PSK;
        memcpy(wifi_config.ap.password, ap_password, strlen(ap_password));
    } else {
        ap_password[0] = '\0';
        encryption_enabled = false;
        wifi_config.ap.authmode = WIFI_AUTH_OPEN;
        wifi_config.ap.password[0] = '\0';
    }
    
    esp_err_t ret = esp_wifi_set_config(WIFI_IF_AP, &wifi_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Password update failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    ESP_LOGI(TAG, "AP password updated: %s", 
             encryption_enabled ? "enabled" : "disabled");
    
    return ESP_OK;
}

uint8_t get_wifi_client_count(void)
{
    return wifi_ap_active ? client_count : 0;
}

bool is_wifi_ap_active(void)
{
    return wifi_ap_active;
}

esp_err_t disconnect_all_clients(void)
{
    if (!wifi_ap_active) {
        return ESP_ERR_INVALID_STATE;
    }
    
    /* Get list of connected stations and deauth them all */
    wifi_sta_list_t sta_list;
    esp_err_t ret = esp_wifi_ap_get_sta_list(&sta_list);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to get station list: %s", esp_err_to_name(ret));
        return ret;
    }
    
    for (int i = 0; i < sta_list.num; i++) {
        ESP_LOGI(TAG, "Force disconnecting station: MAC=" MACSTR,
                 MAC2STR(sta_list.sta[i].mac));
        esp_wifi_deauth_sta(sta_list.sta[i].mac);
    }
    
    client_count = 0;
    
    return ESP_OK;
}

/* DNS Server Implementation */

typedef struct {
    uint16_t transaction_id;
    uint16_t flags;
    uint16_t questions;
    uint16_t answer_rrs;
    uint16_t authority_rrs;
    uint16_t additional_rrs;
} dns_header_t;

static uint16_t dns_create_response(uint8_t* buffer, size_t buffer_size,
                                    const char* query_name, ip4_addr_t* answer_ip)
{
    dns_header_t* header = (dns_header_t*)buffer;
    uint8_t* ptr = buffer + sizeof(dns_header_t);
    size_t name_len = strlen(query_name);
    
    memset(header, 0, sizeof(dns_header_t));
    header->transaction_id = 0x1234;
    header->flags = 0x8180;
    header->questions = 1;
    header->answer_rrs = 1;
    
    memcpy(ptr, query_name, name_len);
    ptr += name_len + 1;
    
    uint16_t* type = (uint16_t*)ptr;
    *type = htons(1);
    ptr += sizeof(uint16_t);
    
    uint16_t* cls = (uint16_t*)ptr;
    *cls = htons(1);
    ptr += sizeof(uint16_t);
    
    uint16_t* name_ptr = (uint16_t*)ptr;
    *name_ptr = htons(0xC000 | sizeof(dns_header_t));
    ptr += sizeof(uint16_t);
    
    uint16_t* rtype = (uint16_t*)ptr;
    *rtype = htons(1);
    ptr += sizeof(uint16_t);
    
    uint16_t* rcls = (uint16_t*)ptr;
    *rcls = htons(1);
    ptr += sizeof(uint16_t);
    
    uint32_t* ttl = (uint32_t*)ptr;
    *ttl = htonl(DNS_DEFAULT_TTL);
    ptr += sizeof(uint32_t);
    
    uint16_t* data_len = (uint16_t*)ptr;
    *data_len = htons(4);
    ptr += sizeof(uint16_t);
    
    uint32_t* rdata = (uint32_t*)ptr;
    *rdata = answer_ip->addr;
    ptr += sizeof(uint32_t);
    
    return (ptr - buffer);
}

esp_err_t init_dns_server(void)
{
    if (dns_server_active) {
        ESP_LOGW(TAG, "DNS server already active");
        return ESP_OK;
    }
    
    ESP_LOGI(TAG, "Initializing DNS server");
    
    /* Create DNS socket */
    dns_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (dns_socket < 0) {
        ESP_LOGE(TAG, "DNS socket creation failed: %d", errno);
        return ESP_FAIL;
    }
    
    /* Set socket timeout */
    struct timeval timeout = {0, 100000};  /* 100ms */
    setsockopt(dns_socket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    
    /* Bind to port 53 */
    memset(&dns_server_addr, 0, sizeof(dns_server_addr));
    dns_server_addr.sin_family = AF_INET;
    dns_server_addr.sin_addr.s_addr = INADDR_ANY;
    dns_server_addr.sin_port = htons(DNS_SERVER_PORT);
    
    if (bind(dns_socket, (struct sockaddr*)&dns_server_addr, 
             sizeof(dns_server_addr)) < 0) {
        ESP_LOGE(TAG, "DNS socket bind failed: %d", errno);
        close(dns_socket);
        dns_socket = -1;
        return ESP_FAIL;
    }
    
    dns_server_active = true;
    
    ESP_LOGI(TAG, "DNS wildcard server started on port %d", DNS_SERVER_PORT);
    
    return ESP_OK;
}

void stop_dns_server(void)
{
    if (!dns_server_active) {
        return;
    }
    
    ESP_LOGI(TAG, "Stopping DNS server");
    
    if (dns_socket >= 0) {
        close(dns_socket);
        dns_socket = -1;
    }
    
    dns_server_active = false;
    
    ESP_LOGI(TAG, "DNS server stopped");
}

void handle_dns_requests(void)
{
    if (!dns_server_active || dns_socket < 0) {
        return;
    }
    
    uint8_t buffer[DNS_BUFFER_SIZE];
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    
    ssize_t recv_len = recvfrom(dns_socket, buffer, sizeof(buffer), 0,
                                (struct sockaddr*)&client_addr, &client_len);
    
    if (recv_len <= 0) {
        return;
    }
    
    dns_header_t* header = (dns_header_t*)buffer;
    
    /* Only respond to queries (QR flag = 0) */
    if ((header->flags & 0x8000) != 0) {
        return;
    }
    
    /* Extract query name (simplified - no compression handling) */
    uint8_t* query_name = buffer + sizeof(dns_header_t);
    char domain_name[256] = {0};
    size_t name_pos = 0;
    
    for (size_t i = 0; query_name[i] != 0 && name_pos < 255; 
         i += query_name[i] + 1) {
        if (name_pos > 0) domain_name[name_pos++] = '.';
        uint8_t label_len = query_name[i];
        if (name_pos + label_len < 255) {
            memcpy(&domain_name[name_pos], &query_name[i + 1], label_len);
            name_pos += label_len;
        }
    }
    
    /* Create response with AP IP */
    uint8_t response[512];
    uint16_t resp_len = dns_create_response(response, sizeof(response), 
                                            domain_name, &ap_ip_addr);
    
    sendto(dns_socket, response, resp_len, 0,
           (struct sockaddr*)&client_addr, client_len);
}

const char* get_ap_ip_address(void)
{
    static char ip_str[16];
    snprintf(ip_str, sizeof(ip_str), IPSTR, IP2STR(&ap_ip_addr));
    return ip_str;
}
