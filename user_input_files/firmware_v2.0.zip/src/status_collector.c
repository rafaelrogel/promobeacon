/**
 * Status Collector Implementation
 * 
 * Monitors and tracks device status including connected clients,
 * session duration, portal engagement time, and battery level.
 */

#include "status_collector.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_adc_cal.h"
#include "driver/adc.h"
#include "esp_wifi.h"
#include <string.h>
#include <stdlib.h>

static const char* TAG = "STATUS";

/* Status state */
static DeviceStatus current_status;
static uint32_t session_start_time = 0;
static uint32_t total_portal_time = 0;
static uint32_t portal_session_count = 0;

/* Client tracking */
static client_info_t clients[MAX_TRACKED_CLIENTS];

/* Battery monitoring */
#define ADC_CHANNEL_BATTERY ADC1_CHANNEL_6
#define DEFAULT_VREF 1100

static esp_adc_cal_characteristics_t adc_chars;
static bool adc_calibrated = false;
static uint8_t last_battery_percent = 100;

/**
 * @brief Initialize status collector
 */
void init_status_collector(void)
{
    memset(&current_status, 0, sizeof(current_status));
    memset(clients, 0, sizeof(clients));
    
    session_start_time = xTaskGetTickCount() * portTICK_PERIOD_MS / 1000;
    total_portal_time = 0;
    portal_session_count = 0;
    
    /* Initialize ADC for battery monitoring */
    adc1_config_width(ADC_WIDTH_BIT_12);
    adc1_config_channel_atten(ADC_CHANNEL_BATTERY, ADC_ATTEN_DB_11);
    
    /* Get ADC calibration */
    esp_adc_cal_characterize(ADC1, ADC_ATTEN_DB_11, ADC_WIDTH_BIT_12, 
                             DEFAULT_VREF, &adc_chars);
    adc_calibrated = true;
    
    /* Initialize battery reading */
    last_battery_percent = update_battery_percent();
    
    ESP_LOGI(TAG, "Status collector initialized");
    ESP_LOGI(TAG, "Session start time: %lu", session_start_time);
}

/**
 * @brief Update status fields
 */
void update_status(void)
{
    uint32_t current_time = xTaskGetTickCount() * portTICK_PERIOD_MS / 1000;
    uint32_t session_seconds = current_time - session_start_time;
    
    /* Update flags */
    current_status.flags = 0x03;  /* Both AP and BLE active */
    
    /* Update client count from WiFi */
    wifi_sta_list_t sta_list;
    esp_wifi_ap_get_sta_list(&sta_list);
    current_status.client_count = sta_list.num;
    
    /* Update session duration */
    current_status.session_duration_sec = (uint16_t)(session_seconds & 0xFFFF);
    
    /* Calculate average portal time */
    if (portal_session_count > 0) {
        current_status.portal_time_avg_sec = (uint8_t)(total_portal_time / portal_session_count);
        if (current_status.portal_time_avg_sec > 255) {
            current_status.portal_time_avg_sec = 255;
        }
    }
    
    /* Update battery every 30 seconds */
    static uint32_t last_battery_update = 0;
    if (current_time - last_battery_update > 30) {
        current_status.battery_percent = update_battery_percent();
        last_battery_update = current_time;
    } else {
        current_status.battery_percent = last_battery_percent;
    }
}

/**
 * @brief Serialize status to buffer
 */
void serialize_status(uint8_t* buffer)
{
    if (!buffer) return;
    
    buffer[0] = current_status.flags;
    buffer[1] = current_status.client_count;
    buffer[2] = (uint8_t)(current_status.session_duration_sec & 0xFF);
    buffer[3] = (uint8_t)((current_status.session_duration_sec >> 8) & 0xFF);
    buffer[4] = current_status.portal_time_avg_sec;
    buffer[5] = current_status.battery_percent;
}

/**
 * @brief Get current status
 */
const DeviceStatus* get_status(void)
{
    return &current_status;
}

/**
 * @brief Handle client connection
 */
void on_client_connected(const uint8_t* mac)
{
    if (!mac) return;
    
    /* Find available slot */
    int slot = -1;
    for (int i = 0; i < MAX_TRACKED_CLIENTS; i++) {
        if (!clients[i].active) {
            slot = i;
            break;
        }
    }
    
    if (slot < 0) {
        ESP_LOGW(TAG, "No available client slots");
        return;
    }
    
    /* Record connection */
    clients[slot].active = true;
    memcpy(clients[slot].mac, mac, 6);
    clients[slot].connect_time = xTaskGetTickCount() * portTICK_PERIOD_MS / 1000;
    clients[slot].portal_start_time = clients[slot].connect_time;
    
    ESP_LOGD(TAG, "Client connected: slot=%d, MAC=" MACSTR, slot, MAC2STR(mac));
}

/**
 * @brief Handle client disconnection
 */
void on_client_disconnected(const uint8_t* mac)
{
    uint32_t current_time = xTaskGetTickCount() * portTICK_PERIOD_MS / 1000;
    
    /* Find matching client */
    for (int i = 0; i < MAX_TRACKED_CLIENTS; i++) {
        if (clients[i].active && memcmp(clients[i].mac, mac, 6) == 0) {
            /* Calculate portal engagement time */
            uint32_t portal_time = current_time - clients[i].portal_start_time;
            total_portal_time += portal_time;
            portal_session_count++;
            
            /* Clear client record */
            clients[i].active = false;
            memset(clients[i].mac, 0, 6);
            
            ESP_LOGD(TAG, "Client disconnected: slot=%d, portal_time=%lu", i, portal_time);
            return;
        }
    }
}

/**
 * @brief Get session duration
 */
uint32_t get_session_duration(void)
{
    uint32_t current_time = xTaskGetTickCount() * portTICK_PERIOD_MS / 1000;
    return current_time - session_start_time;
}

/**
 * @brief Get average portal engagement time
 */
uint8_t get_portal_engagement_time(void)
{
    if (portal_session_count == 0) {
        return 0;
    }
    return (uint8_t)(total_portal_time / portal_session_count);
}

/**
 * @brief Get connected client count
 */
uint8_t get_connected_client_count(void)
{
    return current_status.client_count;
}

/**
 * @brief Update and return battery percentage
 */
uint8_t update_battery_percent(void)
{
    if (!adc_calibrated) {
        return 100;
    }
    
    /* Read ADC multiple times and average */
    uint32_t adc_sum = 0;
    for (int i = 0; i < 8; i++) {
        adc_sum += adc1_get_raw(ADC_CHANNEL_BATTERY);
    }
    uint32_t adc_reading = adc_sum / 8;
    
    /* Convert to voltage */
    uint32_t voltage_mv = esp_adc_cal_raw_to_voltage(adc_reading, &adc_chars);
    
    /* Apply voltage divider compensation (10:1 divider) */
    uint32_t battery_voltage = voltage_mv * 2;
    
    /* Convert to percentage */
    /* Assuming: 4.2V = 100%, 3.2V = 0% */
    uint8_t percent;
    if (battery_voltage >= 4200) {
        percent = 100;
    } else if (battery_voltage <= 3200) {
        percent = 0;
    } else {
        percent = (uint8_t)((battery_voltage - 3200) / 10);
    }
    
    last_battery_percent = percent;
    
    ESP_LOGD(TAG, "Battery: %lu mV, %d%%", battery_voltage, percent);
    
    return percent;
}
