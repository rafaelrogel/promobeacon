/**
 * Web Server Implementation
 * 
 * HTTP server for serving captive portal content and
 * handling form submissions from connected clients.
 */

#include "web_server.h"
#include "ota_update.h"
#include "client_tracker.h"
#include "portal_content.h"
#include "config_manager.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_http_server.h"
#include "esp_wifi.h"
#include "lwip/sockets.h"
#include "lwip/netdb.h"
#include <string.h>
#include <stdlib.h>

static const char* TAG = "WEB_SVR";

/* HTTP server state */
static bool http_server_active = false;
static int http_socket = -1;

/* Portal content */
static char* portal_content = NULL;
static size_t portal_content_size = 0;
static size_t portal_content_length = 0;

/* Client tracking */
static int client_sockets[HTTP_MAX_CONNECTIONS];
static uint32_t client_activity[HTTP_MAX_CONNECTIONS];
static form_submit_callback_t form_callback = NULL;

/* OTA upload state */
static bool ota_upload_active = false;
static uint32_t ota_content_length = 0;
static uint32_t ota_bytes_received = 0;

/* HTTP response templates */
static const char* HTTP_200_RESPONSE = 
    "HTTP/1.1 200 OK\r\n"
    "Content-Type: text/html\r\n"
    "Connection: close\r\n"
    "Content-Length: %d\r\n"
    "\r\n%s";

static const char* HTTP_302_REDIRECT = 
    "HTTP/1.1 302 Found\r\n"
    "Location: /\r\n"
    "Connection: close\r\n"
    "\r\n";

static const char* HTTP_200_POST_RESPONSE = 
    "HTTP/1.1 200 OK\r\n"
    "Content-Type: text/plain\r\n"
    "Content-Length: 25\r\n"
    "Connection: close\r\n"
    "\r\nThanks for your submission!";

static const char* HTTP_404_RESPONSE = 
    "HTTP/1.1 404 Not Found\r\n"
    "Content-Type: text/plain\r\n"
    "Content-Length: 9\r\n"
    "Connection: close\r\n"
    "\r\nNot Found";

static const char* HTTP_500_RESPONSE = 
    "HTTP/1.1 500 Internal Server Error\r\n"
    "Content-Type: text/plain\r\n"
    "Connection: close\r\n"
    "\r\nUpdate Failed";

static const char* HTTP_204_RESPONSE = 
    "HTTP/1.1 204 No Content\r\n"
    "Connection: close\r\n"
    "\r\n";

/**
 * @brief Generate setup portal HTML with device ID
 */
static const char* get_setup_html(const char* device_id)
{
    static char setup_buffer[4096];
    const char* id = device_id ? device_id : "PB-UNKNOWN";

    snprintf(setup_buffer, sizeof(setup_buffer),
"<!DOCTYPE html>"
"<html>"
"<head>"
"<meta charset=\"UTF-8\">"
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
"<title>PromoBeacon Setup</title>"
"<style>"
"body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }"
".container { max-width: 500px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }"
"h1 { color: #333; margin-bottom: 20px; }"
"label { display: block; margin: 15px 0 5px; color: #555; font-weight: bold; }"
"input[type=\"text\"], input[type=\"password\"] { width: 100%%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }"
"input[type=\"submit\"] { width: 100%%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 5px; margin-top: 20px; cursor: pointer; font-size: 16px; }"
"input[type=\"submit\"]:hover { background: #0056b3; }"
".note { font-size: 12px; color: #888; margin-top: 5px; }"
".warning { background: #fff3cd; border: 1px solid #ffc107; padding: 10px; border-radius: 5px; margin-bottom: 15px; color: #856404; }"
".device-id { color: #999; font-size: 12px; font-family: monospace; text-align: center; margin-top: 20px; }"
"</style>"
"</head>"
"<body>"
"<div class=\"container\">"
"<h1>PromoBeacon Setup</h1>"
"<div class=\"warning\">Complete your device configuration below. After setup, the admin portal will be locked.</div>"
"<form method=\"POST\" action=\"/setup\">"
"<label>Promo Text / Message:</label>"
"<input type=\"text\" name=\"promo_text\" placeholder=\"e.g., 10% OFF TODAY\" maxlength=\"32\" required>"
"<div class=\"note\">This text will be shown as your WiFi network name</div>"
""
"<label>WiFi Password (optional):</label>"
"<input type=\"password\" name=\"wifi_password\" placeholder=\"Min 8 characters\" minlength=\"8\">"
"<div class=\"note\">Leave empty for open network, or set a password to secure your beacon</div>"
""
"<label>Admin Password (optional):</label>"
"<input type=\"password\" name=\"admin_password\" placeholder=\"Min 4 characters\" minlength=\"4\">"
"<div class=\"note\">Set a password to lock configuration. You'll need the mobile app + this password to reconfigure later.</div>"
""
"<input type=\"submit\" value=\"Complete Setup\">"
"</form>"
"<div class=\"device-id\">Device ID: %s</div>"
"</div>"
"</body>"
"</html>", id);

    return setup_buffer;
}

/**
 * @brief Parse HTTP request
 */
static void parse_request(const char* buffer, size_t len,
                         char* method, size_t method_len,
                         char* path, size_t path_len,
                         char* body, size_t body_len)
{
    /* Find method */
    const char* ptr = buffer;
    const char* end = buffer + len;
    
    while (ptr < end && *ptr != ' ' && method_len > 1) {
        *method++ = *ptr++;
        method_len--;
    }
    *method = '\0';
    
    /* Skip spaces */
    while (ptr < end && *ptr == ' ') ptr++;
    
    /* Find path */
    while (ptr < end && *ptr != ' ' && *ptr != '\r' && *ptr != '\n' && path_len > 1) {
        *path++ = *ptr++;
        path_len--;
    }
    *path = '\0';
    
    /* Find body for POST requests */
    if (strcmp(method, "POST") == 0) {
        const char* body_start = strstr(buffer, "\r\n\r\n");
        if (body_start != NULL) {
            body_start += 4;
            size_t body_available = end - body_start;
            size_t copy_len = body_available < (body_len - 1) ? body_available : (body_len - 1);
            memcpy(body, body_start, copy_len);
            body[copy_len] = '\0';
        }
    }
}

/**
 * @brief Extract Content-Length from HTTP headers
 */
static uint32_t extract_content_length(const char* buffer, size_t len)
{
    const char* header_start = strstr(buffer, "Content-Length:");
    if (header_start == NULL) {
        return 0;
    }
    
    /* Skip "Content-Length:" and any spaces */
    header_start += 15;
    while (*header_start == ' ') header_start++;
    
    /* Parse the number */
    uint32_t value = 0;
    while (*header_start >= '0' && *header_start <= '9') {
        value = value * 10 + (*header_start - '0');
        header_start++;
    }
    
    return value;
}

/**
 * @brief Get client MAC address from socket
 *
 * Looks up the client's MAC address from their IP address
 * using the WiFi station list in softAP mode.
 *
 * @param client_fd Client socket file descriptor
 * @param mac_addr Output buffer for MAC address (6 bytes)
 * @return true if MAC found, false otherwise
 */
static bool get_client_mac_from_socket(int client_fd, uint8_t* mac_addr)
{
    if (mac_addr == NULL) {
        return false;
    }
    
    /* Get peer address */
    struct sockaddr_in6 peer_addr;
    socklen_t addr_len = sizeof(peer_addr);
    
    if (getpeername(client_fd, (struct sockaddr*)&peer_addr, &addr_len) < 0) {
        return false;
    }
    
    /* Get station list from softAP */
    wifi_sta_list_t sta_list;
    esp_err_t ret = esp_wifi_ap_get_sta_list(&sta_list);
    
    if (ret != ESP_OK || sta_list.num == 0) {
        return false;
    }
    
    /* Search for matching station by comparing addresses */
    /* In softAP mode, we need to match the peer address with station info */
    /* For simplicity, return the first station's MAC if available */
    /* A more robust solution would compare the IP addresses */
    
    /* Try to find a station - for now, use first station */
    /* This is a limitation since we're in raw socket mode without IP tracking */
    memcpy(mac_addr, sta_list.sta[0].mac, 6);
    return true;
}

/**
 * @brief Log HTTP request to client tracker
 */
static void log_request_to_tracker(int client_fd, const char* path, bool is_outgoing, size_t bytes)
{
    static uint8_t last_mac[6] = {0};
    static int last_fd = -1;
    static bool mac_lookup_failed = false;
    
    /* Reuse last MAC for this connection if lookup already failed */
    if (client_fd == last_fd && mac_lookup_failed) {
        if (last_mac[0] != 0 || last_mac[1] != 0 || last_mac[2] != 0 ||
            last_mac[3] != 0 || last_mac[4] != 0 || last_mac[5] != 0) {
            tracker_on_request(last_mac, path, is_outgoing, bytes);
        }
        return;
    }
    
    /* Try to get MAC address */
    uint8_t mac[6];
    bool found = get_client_mac_from_socket(client_fd, mac);
    
    if (found) {
        memcpy(last_mac, mac, 6);
        last_fd = client_fd;
        mac_lookup_failed = false;
        tracker_on_request(mac, path, is_outgoing, bytes);
    } else {
        /* MAC lookup failed, mark as failed for this connection */
        last_fd = client_fd;
        mac_lookup_failed = true;
        ESP_LOGW(TAG, "Could not resolve MAC for client on socket %d", client_fd);
    }
}

/**
 * @brief Process HTTP client request
 */
static void process_client(int client_fd)
{
    char buffer[HTTP_BUFFER_SIZE];
    ssize_t read_len = recv(client_fd, buffer, sizeof(buffer) - 1, 0);
    
    if (read_len <= 0) {
        /* Connection closed or error */
        return;
    }
    
    buffer[read_len] = '\0';
    client_activity[client_fd] = xTaskGetTickCount() * portTICK_PERIOD_MS;
    
    /* Parse request */
    char method[8] = {0};
    char path[HTTP_MAX_URI_LENGTH] = {0};
    char body[512] = {0};
    
    parse_request(buffer, read_len, method, sizeof(method),
                  path, sizeof(path), body, sizeof(body));
    
    /* Log request to client tracker */
    log_request_to_tracker(client_fd, path, true, read_len);
    
    /* Route request */
    if (strcmp(method, "GET") == 0 && strcmp(path, "/") == 0) {
        /* Check if device is configured */
        if (!is_device_configured()) {
            /* Device not configured - show setup portal with device ID */
            char device_id[MAX_DEVICE_ID_LENGTH];
            get_device_id(device_id, sizeof(device_id));

            const char* setup_html = get_setup_html(device_id);
            char response[8192];
            int resp_len = snprintf(response, sizeof(response),
                                    HTTP_200_RESPONSE, (int)strlen(setup_html), setup_html);
            send(client_fd, response, resp_len, 0);
            log_request_to_tracker(client_fd, path, false, resp_len);
        } else {
            /* Device configured - serve promotional content */
            char device_id[MAX_DEVICE_ID_LENGTH];
            get_device_id(device_id, sizeof(device_id));

            /* Use default HTML with device ID if no custom content */
            if (portal_content_length == 0 || !portal_content_get()) {
                const char* promo_text = get_config()->promo_text;
                const char* default_html = portal_get_default_html_with_id(promo_text, device_id);
                set_portal_content(default_html, strlen(default_html));
            }

            char response[10240];
            int content_len = portal_content_length;
            int resp_len = snprintf(response, sizeof(response),
                                    HTTP_200_RESPONSE, content_len, portal_content);
            send(client_fd, response, resp_len, 0);
            log_request_to_tracker(client_fd, path, false, resp_len);
        }
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/setup") == 0) {
        /* Handle initial setup submission */
        ESP_LOGI(TAG, "Setup form submission: %s", body);

        /* Parse form data */
        char promo_text[64] = {0};
        char wifi_password[64] = {0};
        char admin_password[64] = {0};

        /* Simple form parsing */
        const char* promo_ptr = strstr(body, "promo_text=");
        if (promo_ptr) {
            promo_ptr += 11;  /* Skip "promo_text=" */
            size_t i = 0;
            while (*promo_ptr && *promo_ptr != '&' && i < 63) {
                if (*promo_ptr == '+') promo_text[i++] = ' ';
                else promo_text[i++] = *promo_ptr;
                promo_ptr++;
            }
        }

        const char* wifi_ptr = strstr(body, "wifi_password=");
        if (wifi_ptr) {
            wifi_ptr += 14;  /* Skip "wifi_password=" */
            size_t i = 0;
            while (*wifi_ptr && *wifi_ptr != '&' && i < 63) {
                if (*wifi_ptr == '+') wifi_password[i++] = ' ';
                else wifi_password[i++] = *wifi_ptr;
                wifi_ptr++;
            }
        }

        const char* admin_ptr = strstr(body, "admin_password=");
        if (admin_ptr) {
            admin_ptr += 15;  /* Skip "admin_password=" */
            size_t i = 0;
            while (*admin_ptr && *admin_ptr != '&' && i < 63) {
                if (*admin_ptr == '+') admin_password[i++] = ' ';
                else admin_password[i++] = *admin_ptr;
                admin_ptr++;
            }
        }

        /* Save configuration */
        esp_err_t ret = save_promo_text(promo_text);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Failed to save promo text");
        }

        if (strlen(wifi_password) > 0) {
            save_wifi_password(wifi_password);
        } else {
            save_wifi_password(NULL);
        }

        if (strlen(admin_password) > 0) {
            save_admin_password(admin_password);
        }

        /* Mark device as configured */
        set_device_configured();

        /* Send success response */
        const char* success_html =
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: text/html\r\n"
            "Connection: close\r\n"
            "\r\n"
            "<!DOCTYPE html>"
            "<html>"
            "<head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
            "<title>Setup Complete</title>"
            "<style>body { font-family: Arial, sans-serif; margin: 20px; text-align: center; }"
            ".container { max-width: 400px; margin: 50px auto; padding: 30px; background: #d4edda; border-radius: 10px; border: 1px solid #c3e6cb; }"
            "h1 { color: #155724; } p { color: #155724; }</style>"
            "</head>"
            "<body>"
            "<div class=\"container\">"
            "<h1>Setup Complete!</h1>"
            "<p>Your PromoBeacon is now configured and ready to use.</p>"
            "<p>The device will now show your promotional content to customers.</p>"
            "<p>To reconfigure later, use the mobile app or reflash the firmware.</p>"
            "</div>"
            "</body>"
            "</html>";

        send(client_fd, success_html, strlen(success_html), 0);
        log_request_to_tracker(client_fd, path, false, strlen(success_html));
        /* Handle form submission */
        ESP_LOGI(TAG, "Form submission: %s", body);
        if (form_callback) {
            form_callback(body, strlen(body));
        }
        send(client_fd, HTTP_200_POST_RESPONSE, strlen(HTTP_200_POST_RESPONSE), 0);
        log_request_to_tracker(client_fd, path, false, strlen(HTTP_200_POST_RESPONSE));
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/update") == 0) {
        /* Handle OTA firmware update */
        ESP_LOGI(TAG, "OTA firmware update request received");
        
        /* Extract Content-Length */
        uint32_t content_length = extract_content_length(buffer, read_len);
        
        if (content_length == 0) {
            ESP_LOGE(TAG, "No Content-Length header in update request");
            send(client_fd, HTTP_500_RESPONSE, strlen(HTTP_500_RESPONSE), 0);
            log_request_to_tracker(client_fd, path, false, strlen(HTTP_500_RESPONSE));
        } else {
            /* Initialize OTA if not already active */
            if (!ota_upload_active) {
                esp_err_t ret = ota_begin();
                if (ret != ESP_OK) {
                    ESP_LOGE(TAG, "Failed to start OTA: %s", esp_err_to_name(ret));
                    send(client_fd, HTTP_500_RESPONSE, strlen(HTTP_500_RESPONSE), 0);
                    log_request_to_tracker(client_fd, path, false, strlen(HTTP_500_RESPONSE));
                } else {
                    ota_upload_active = true;
                    ota_content_length = content_length;
                    ota_bytes_received = 0;
                    ota_set_total_size(content_length);
                    
                    ESP_LOGI(TAG, "Starting OTA upload - %u bytes expected", content_length);
                    
                    /* Write any body data in the initial request */
                    if (body[0] != '\0') {
                        size_t body_len = strlen(body);
                        esp_err_t write_ret = ota_write(body, body_len);
                        if (write_ret == ESP_OK) {
                            ota_bytes_received += body_len;
                            ESP_LOGI(TAG, "OTA progress: %u / %u bytes", 
                                     ota_bytes_received, ota_content_length);
                        }
                    }
                    
                    /* Send success response - more data coming */
                    const char* continue_response = 
                        "HTTP/1.1 100 Continue\r\n"
                        "Connection: keep-alive\r\n"
                        "\r\n";
                    send(client_fd, continue_response, strlen(continue_response), 0);
                    log_request_to_tracker(client_fd, path, false, strlen(continue_response));
                }
            } else {
                /* Continue receiving firmware data */
                if (body[0] != '\0') {
                    esp_err_t ret = ota_write(body, strlen(body));
                    if (ret == ESP_OK) {
                        ota_bytes_received += strlen(body);
                        ESP_LOGI(TAG, "OTA progress: %u / %u bytes", 
                                 ota_bytes_received, ota_content_length);
                    }
                }
                /* Keep connection open for more data */
            }
        }
    } else if (strcmp(method, "GET") == 0 && strcmp(path, "/update") == 0) {
        /* Serve OTA update status page */
        char status_str[128];
        ota_get_status_string(status_str, sizeof(status_str));
        
        char response[1024];
        int resp_len = snprintf(response, sizeof(response),
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: text/html\r\n"
            "Connection: close\r\n"
            "\r\n"
            "<!DOCTYPE html><html><head><title>Firmware Update</title></head>"
            "<body><h1>Firmware Update</h1>"
            "<p>Status: %s</p>"
            "<form method='POST' action='/update' enctype='multipart/form-data'>"
            "<input type='file' name='firmware'>"
            "<input type='submit' value='Update'>"
            "</form></body></html>",
            status_str);
        send(client_fd, response, resp_len, 0);
        log_request_to_tracker(client_fd, path, false, resp_len);
    } else if (strcmp(method, "GET") == 0 && strcmp(path, "/stats.csv") == 0) {
        /* Serve CSV statistics export */
        ESP_LOGI(TAG, "CSV stats export requested");
        
        /* Generate CSV data */
        size_t csv_size = tracker_get_csv_size();
        char* csv_buffer = (char*)malloc(csv_size);
        if (!csv_buffer) {
            ESP_LOGE(TAG, "Failed to allocate CSV buffer");
            const char* error_response = 
                "HTTP/1.1 500 Internal Server Error\r\n"
                "Content-Type: text/plain\r\n"
                "Content-Length: 25\r\n"
                "Connection: close\r\n"
                "\r\nFailed to generate CSV";
            send(client_fd, error_response, strlen(error_response), 0);
        } else {
            uint32_t csv_len = tracker_generate_csv(csv_buffer, csv_size);
            
            if (csv_len == 0) {
                ESP_LOGE(TAG, "Failed to generate CSV data");
                free(csv_buffer);
                const char* error_response = 
                    "HTTP/1.1 500 Internal Server Error\r\n"
                    "Content-Type: text/plain\r\n"
                    "Content-Length: 22\r\n"
                    "Connection: close\r\n"
                    "\r\nCSV generation failed";
                send(client_fd, error_response, strlen(error_response), 0);
            } else {
                /* Generate filename with timestamp */
                char filename[64];
                time_t now = time(NULL);
                struct tm* timeinfo = localtime(&now);
                strftime(filename, sizeof(filename), "stats_%Y%m%d_%H%M%S.csv", timeinfo);
                
                /* Build HTTP response with CSV headers */
                char header[256];
                int header_len = snprintf(header, sizeof(header),
                    "HTTP/1.1 200 OK\r\n"
                    "Content-Type: text/csv\r\n"
                    "Content-Disposition: attachment; filename=\"%s\"\r\n"
                    "Content-Length: %lu\r\n"
                    "Connection: close\r\n"
                    "\r\n",
                    filename,
                    (unsigned long)csv_len);
                
                /* Send header */
                send(client_fd, header, header_len, 0);
                
                /* Send CSV data */
                send(client_fd, csv_buffer, csv_len, 0);
                
                ESP_LOGI(TAG, "CSV sent: %lu bytes", (unsigned long)csv_len);
                free(csv_buffer);
            }
        }
    } else {
        /* Redirect unknown paths to root */
        send(client_fd, HTTP_302_REDIRECT, strlen(HTTP_302_REDIRECT), 0);
        log_request_to_tracker(client_fd, path, false, strlen(HTTP_302_REDIRECT));
    }
    
    /* Close connection */
    shutdown(client_fd, SHUT_RDWR);
    close(client_fd);
}

/**
 * @brief Accept new HTTP connection
 */
static void accept_connections(void)
{
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    
    int client_fd = accept(http_socket, (struct sockaddr*)&client_addr, &client_len);
    if (client_fd < 0) {
        return;
    }
    
    /* Find available slot */
    int slot = -1;
    for (int i = 0; i < HTTP_MAX_CONNECTIONS; i++) {
        if (client_sockets[i] < 0) {
            slot = i;
            break;
        }
    }
    
    if (slot < 0) {
        /* No available slots - reject connection */
        close(client_fd);
        return;
    }
    
    /* Accept connection */
    client_sockets[slot] = client_fd;
    client_activity[slot] = xTaskGetTickCount() * portTICK_PERIOD_MS;
}

/**
 * @brief Check and process active connections
 */
static void process_connections(void)
{
    uint32_t current_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
    
    for (int i = 0; i < HTTP_MAX_CONNECTIONS; i++) {
        if (client_sockets[i] < 0) {
            continue;
        }
        
        /* Check timeout */
        if (current_time - client_activity[i] > HTTP_TIMEOUT_MS) {
            shutdown(client_sockets[i], SHUT_RDWR);
            close(client_sockets[i]);
            client_sockets[i] = -1;
            client_activity[i] = 0;
            continue;
        }
        
        /* Check for available data (non-blocking) */
        struct timeval timeout = {0, 0};
        setsockopt(client_sockets[i], SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
        
        char buffer[HTTP_BUFFER_SIZE];
        ssize_t read_len = recv(client_sockets[i], buffer, sizeof(buffer) - 1, MSG_PEEK);
        
        if (read_len > 0) {
            /* Data available - process request */
            process_client(client_sockets[i]);
            client_sockets[i] = -1;
            client_activity[i] = 0;
        } else if (read_len == 0) {
            /* Connection closed */
            close(client_sockets[i]);
            client_sockets[i] = -1;
            client_activity[i] = 0;
        }
        /* read_len < 0 with EAGAIN means no data available */
    }
}

esp_err_t init_http_server(void)
{
    if (http_server_active) {
        ESP_LOGW(TAG, "HTTP server already active");
        return ESP_OK;
    }
    
    ESP_LOGI(TAG, "Initializing HTTP server");
    
    /* Initialize portal content manager (loads custom content if available) */
    esp_err_t ret = portal_content_init();
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "Failed to init portal content, using default");
    }
    
    /* Allocate portal content buffer */
    portal_content_size = MAX_PORTAL_HTML_SIZE;
    portal_content = (char*)malloc(portal_content_size);
    if (!portal_content) {
        ESP_LOGE(TAG, "Failed to allocate portal content buffer");
        return ESP_ERR_NO_MEM;
    }
    
    /* Try to load custom content from portal_content module, or use default */
    const char* custom_content = portal_content_get();
    if (custom_content && strlen(custom_content) > 0) {
        strncpy(portal_content, custom_content, portal_content_size - 1);
        ESP_LOGI(TAG, "Using custom portal content: %u bytes", 
                 (unsigned int)strlen(custom_content));
    } else {
        /* Get device ID for default content */
        char device_id[MAX_DEVICE_ID_LENGTH];
        get_device_id(device_id, sizeof(device_id));

        /* Use default content with device ID */
        const char* default_html = portal_get_default_html_with_id("Welcome!", device_id);
        if (default_html) {
            strncpy(portal_content, default_html, portal_content_size - 1);
        } else {
            /* Fallback to minimal default */
            strcpy(portal_content, "<html><body><h1>Welcome!</h1></body></html>");
        }
    }
    
    portal_content[portal_content_size - 1] = '\0';
    portal_content_length = strlen(portal_content);
    
    /* Initialize client sockets */
    for (int i = 0; i < HTTP_MAX_CONNECTIONS; i++) {
        client_sockets[i] = -1;
        client_activity[i] = 0;
    }
    
    /* Create server socket */
    http_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (http_socket < 0) {
        ESP_LOGE(TAG, "Socket creation failed: %d", errno);
        free(portal_content);
        portal_content = NULL;
        return ESP_FAIL;
    }
    
    /* Set socket options */
    int opt = 1;
    setsockopt(http_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    /* Bind to port 80 */
    struct sockaddr_in server_addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = INADDR_ANY,
        .sin_port = htons(HTTP_SERVER_PORT),
    };
    
    if (bind(http_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        ESP_LOGE(TAG, "Socket bind failed: %d", errno);
        close(http_socket);
        http_socket = -1;
        free(portal_content);
        portal_content = NULL;
        return ESP_FAIL;
    }
    
    /* Listen for connections */
    if (listen(http_socket, HTTP_MAX_CONNECTIONS) < 0) {
        ESP_LOGE(TAG, "Socket listen failed: %d", errno);
        close(http_socket);
        http_socket = -1;
        free(portal_content);
        portal_content = NULL;
        return ESP_FAIL;
    }
    
    http_server_active = true;
    
    ESP_LOGI(TAG, "HTTP server started on port %d", HTTP_SERVER_PORT);
    
    return ESP_OK;
}

void stop_http_server(void)
{
    if (!http_server_active) {
        return;
    }
    
    ESP_LOGI(TAG, "Stopping HTTP server");
    
    /* Abort any ongoing OTA upload */
    if (ota_upload_active) {
        ota_abort();
        ota_upload_active = false;
        ESP_LOGW(TAG, "OTA upload aborted due to server stop");
    }
    
    /* Close all client connections */
    for (int i = 0; i < HTTP_MAX_CONNECTIONS; i++) {
        if (client_sockets[i] >= 0) {
            shutdown(client_sockets[i], SHUT_RDWR);
            close(client_sockets[i]);
            client_sockets[i] = -1;
        }
    }
    
    /* Close server socket */
    if (http_socket >= 0) {
        close(http_socket);
        http_socket = -1;
    }
    
    /* Free portal content buffer */
    if (portal_content) {
        free(portal_content);
        portal_content = NULL;
    }
    
    portal_content_size = 0;
    portal_content_length = 0;
    form_callback = NULL;
    
    /* Deinitialize portal content manager */
    portal_content_deinit();
    
    http_server_active = false;
    
    ESP_LOGI(TAG, "HTTP server stopped");
}

void handle_http_requests(void)
{
    if (!http_server_active) {
        return;
    }
    
    /* Accept new connections */
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    
    /* Check for new connections (non-blocking) */
    struct timeval timeout = {0, 0};
    setsockopt(http_socket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    
    int client_fd = accept(http_socket, (struct sockaddr*)&client_addr, &client_len);
    if (client_fd >= 0) {
        /* Find available slot */
        int slot = -1;
        for (int i = 0; i < HTTP_MAX_CONNECTIONS; i++) {
            if (client_sockets[i] < 0) {
                slot = i;
                break;
            }
        }
        
        if (slot >= 0) {
            client_sockets[slot] = client_fd;
            client_activity[slot] = xTaskGetTickCount() * portTICK_PERIOD_MS;
        } else {
            close(client_fd);
        }
    }
    
    /* Process active connections */
    process_connections();
}

esp_err_t set_portal_content(const char* html_content, size_t length)
{
    if (!html_content || length == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    if (length >= portal_content_size) {
        /* Reallocate buffer */
        char* new_buffer = (char*)realloc(portal_content, length + 1);
        if (!new_buffer) {
            ESP_LOGE(TAG, "Failed to reallocate portal buffer");
            return ESP_ERR_NO_MEM;
        }
        portal_content = new_buffer;
        portal_content_size = length + 1;
    }

    memcpy(portal_content, html_content, length);
    portal_content[length] = '\0';
    portal_content_length = length;

    return ESP_OK;
}

esp_err_t update_portal_content_with_text(const char* text)
{
    if (!text) {
        return ESP_ERR_INVALID_ARG;
    }

    /* Use portal_content module to generate default HTML with promo text */
    const char* html_content = portal_get_default_html(text);
    if (html_content == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    size_t len = strlen(html_content);
    return set_portal_content(html_content, len);
}

const char* get_portal_content(void)
{
    return portal_content ? portal_content : "";
}

size_t get_portal_content_length(void)
{
    return portal_content_length;
}

void register_form_callback(form_submit_callback_t callback)
{
    form_callback = callback;
}

bool is_http_server_active(void)
{
    return http_server_active;
}

uint8_t get_http_connection_count(void)
{
    uint8_t count = 0;
    for (int i = 0; i < HTTP_MAX_CONNECTIONS; i++) {
        if (client_sockets[i] >= 0) {
            count++;
        }
    }
    return count;
}

esp_err_t complete_ota_update(void)
{
    if (!ota_upload_active) {
        return ESP_ERR_INVALID_STATE;
    }
    
    ESP_LOGI(TAG, "Completing OTA update...");
    
    esp_err_t ret = ota_end();
    
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "OTA update completed successfully");
        ota_upload_active = false;
        
        /* Send notification that restart is needed */
        ESP_LOGI(TAG, "Device will restart to apply new firmware");
    } else {
        ESP_LOGE(TAG, "OTA update failed: %s", esp_err_to_name(ret));
        ota_upload_active = false;
    }
    
    return ret;
}

void abort_ota_update(void)
{
    if (ota_upload_active) {
        ota_abort();
        ota_upload_active = false;
        ESP_LOGW(TAG, "OTA update aborted");
    }
}

bool is_ota_update_active(void)
{
    return ota_upload_active;
}

bool is_in_setup_mode(void)
{
    /* Device is in setup mode if not configured yet */
    return !is_device_configured();
}

esp_err_t complete_setup(void)
{
    /* Mark device as configured - locks out web portal admin */
    return set_device_configured();
}
