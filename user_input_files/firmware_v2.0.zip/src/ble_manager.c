/**
 * BLE Manager Implementation - G Mode GATT Service
 * 
 * Provides BLE GATT service for G Mode (WiFi AP + Captive Portal).
 * Handles configuration, and status monitoring.
 * 
 * Architecture:
 * - BLE stack initialized at boot
 * - GATT service for configuration
 * - Status notifications sent on state changes
 * 
 * Author: MiniMax Agent
 * Version: 3.0.0
 */

#include "ble_manager.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_bt.h"
#include "esp_bt_main.h"
#include "esp_gap_ble_api.h"
#include "esp_gatts_api.h"
#include "esp_bt_defs.h"
#include "nvs_flash.h"
#include "string.h"
#include "stdlib.h"
#include "freertos/FreeRTOS.h"
#include "freertos/timers.h"
#include "g_mode.h"
#include "config_manager.h"
#include "ota_update.h"
#include "client_tracker.h"
#include "portal_content.h"

static const char *TAG = "BLE_MANAGER";

/* NVS namespace and keys */
#define BLE_NVS_NAMESPACE          "ble_manager"
#define BLE_NVS_MESSAGE            "message"
#define BLE_NVS_PROMO_TEXT         "promo_text"
#define BLE_NVS_MAJOR              "major"
#define BLE_NVS_MINOR              "minor"
#define BLE_NVS_TX_POWER           "tx_power"
#define KEY_ADMIN_PASSWORD         "admin_pass"
#define MIN_ADMIN_PASSWORD_LENGTH  4

/* Static configuration */
static DeviceMode g_current_mode = MODE_G;
static bool g_initialized = false;

/* Connection state */
static ConnectionState g_conn_state = CONN_STATE_DISCONNECTED;
static uint8_t g_client_count = 0;
static int8_t g_current_rssi = -60;

/* GATT interface and handles */
static uint16_t g_gatts_if = 0;
static uint16_t g_conn_id = 0;

/* Attribute handles */
static uint16_t g_handle_auth = 0;
static uint16_t g_handle_auth_val = 0;
static uint16_t g_handle_auth_status = 0;
static uint16_t g_handle_auth_status_val = 0;
static uint16_t g_handle_auth_status_cccd = 0;
static uint16_t g_handle_device_name = 0;
static uint16_t g_handle_device_name_val = 0;
static uint16_t g_handle_mode_control = 0;
static uint16_t g_handle_mode_control_val = 0;
static uint16_t g_handle_message = 0;
static uint16_t g_handle_message_val = 0;
static uint16_t g_handle_config = 0;
static uint16_t g_handle_config_val = 0;
static uint16_t g_handle_status = 0;
static uint16_t g_handle_status_val = 0;
static uint16_t g_handle_status_cccd = 0;
static uint16_t g_handle_promo_text = 0;
static uint16_t g_handle_promo_text_val = 0;
static uint16_t g_handle_stats = 0;
static uint16_t g_handle_stats_val = 0;
static uint16_t g_handle_stats_cccd = 0;
static uint16_t g_handle_sessions = 0;
static uint16_t g_handle_sessions_val = 0;
static uint16_t g_handle_session_ctrl = 0;
static uint16_t g_handle_session_ctrl_val = 0;
static uint16_t g_handle_portal_data = 0;
static uint16_t g_handle_portal_data_val = 0;
static uint16_t g_handle_portal_ctrl = 0;
static uint16_t g_handle_portal_ctrl_val = 0;
static uint16_t g_handle_portal_ctrl_cccd = 0;

/* Characteristic values */
static uint8_t g_mode_value = MODE_G;
static char g_message_value[MAX_MESSAGE_LENGTH + 1] = "VISITE-NOS";
static char g_promo_text_value[MAX_PROMO_TEXT_LENGTH + 1] = "PROMO-BEACON";
static DeviceStatus g_status_value = {0};

/* Stats buffer */
static char g_stats_buffer[128] = {0};

/* Session data buffer for BLE transfer */
static uint8_t g_sessions_buffer[512] = {0};
static uint16_t g_sessions_buffer_len = 0;

/* Authentication state */
static bool g_is_authenticated = false;
static uint32_t g_auth_fail_count = 0;

/* BLE Security state */
static bool g_security_enabled = false;
static char g_passkey[7] = {0};  /* 6-digit passkey + null terminator */
static uint8_t g_auth_status = AUTH_STATUS_REQUIRED;

/* Device name */
static char g_device_name_value[MAX_DEVICE_NAME_LENGTH + 1] = "PROMO-BEACON";

/* Advertising data */
static uint8_t g_adv_data[64];
static size_t g_adv_data_len = 0;

/* Callbacks */
static mode_change_callback_t g_mode_change_callback = NULL;
static status_update_callback_t g_status_update_callback = NULL;

/* Timer for status updates */
static TimerHandle_t g_status_timer = NULL;

/* Configuration values */
static uint16_t g_beacon_major = 1;
static uint16_t g_beacon_minor = 1;
static int8_t g_beacon_tx_power = -59;

/* 128-bit UUID definitions */
static const uint8_t PROMO_SERVICE_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_MODE_CONTROL_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x79, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_MESSAGE_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x7A, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_CONFIG_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x7B, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_STATUS_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x7C, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_PROMO_TEXT_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x7D, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_STATS_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x7E, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_SESSIONS_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x7F, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_SESSION_CTRL_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x80, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_PORTAL_DATA_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x81, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_PORTAL_CTRL_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x82, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_AUTH_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x83, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

static const uint8_t CHAR_DEVICE_NAME_UUID128[16] = {
    0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12, 0x84, 0x56,
    0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x78, 0x56
};

/* GATT attribute database */
enum {
    ATTR_IDX_SERVICE,
    ATTR_IDX_AUTH,
    ATTR_IDX_AUTH_VAL,
    ATTR_IDX_DEVICE_NAME,
    ATTR_IDX_DEVICE_NAME_VAL,
    ATTR_IDX_MODE_CONTROL,
    ATTR_IDX_MODE_CONTROL_VAL,
    ATTR_IDX_MESSAGE,
    ATTR_IDX_MESSAGE_VAL,
    ATTR_IDX_CONFIG,
    ATTR_IDX_CONFIG_VAL,
    ATTR_IDX_STATUS,
    ATTR_IDX_STATUS_VAL,
    ATTR_IDX_STATUS_CCCD,
    ATTR_IDX_PROMO_TEXT,
    ATTR_IDX_PROMO_TEXT_VAL,
    ATTR_IDX_STATS,
    ATTR_IDX_STATS_VAL,
    ATTR_IDX_STATS_CCCD,
    ATTR_IDX_SESSIONS,
    ATTR_IDX_SESSIONS_VAL,
    ATTR_IDX_SESSION_CTRL,
    ATTR_IDX_SESSION_CTRL_VAL,
    ATTR_IDX_PORTAL_DATA,
    ATTR_IDX_PORTAL_DATA_VAL,
    ATTR_IDX_PORTAL_CTRL,
    ATTR_IDX_PORTAL_CTRL_VAL,
    ATTR_IDX_PORTAL_CTRL_CCCD,
    ATTR_IDX_TOTAL
};

static const uint16_t GATT_PRIMARY_SERVICE_UUID = ESP_GATT_UUID_PRI_SERVICE;
static const uint16_t GATT_CHAR_UUID = ESP_GATT_UUID_CHAR_DECLARE;
static const uint16_t GATT_CHAR_CLIENT_CONFIG = ESP_GATT_UUID_CHAR_CLIENT_CONFIG;

static const uint16_t CHAR_PROP_READ = ESP_GATT_CHAR_PROP_BIT_READ;
static const uint16_t CHAR_PROP_WRITE = ESP_GATT_CHAR_PROP_BIT_WRITE;
static const uint16_t CHAR_PROP_NOTIFY = ESP_GATT_CHAR_PROP_BIT_NOTIFY;
static const uint16_t CHAR_PROP_RW = CHAR_PROP_READ | CHAR_PROP_WRITE;
static const uint16_t CHAR_PROP_RWN = CHAR_PROP_READ | CHAR_PROP_WRITE | CHAR_PROP_NOTIFY;

static const uint16_t ATT_PERM_READ = ESP_GATT_PERM_READ;
static const uint16_t ATT_PERM_WRITE = ESP_GATT_PERM_WRITE;

static esp_gatts_attr_db_t gatt_db[ATTR_IDX_TOTAL] = {
    /* Service Declaration */
    [ATTR_IDX_SERVICE] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_PRIMARY_SERVICE_UUID},
        {ATT_PERM_READ, sizeof(uint16_t), 0, (uint8_t*)&PROMO_SERVICE_UUID128[0]}
    },

    /* Authentication Characteristic - Write Only for password submission */
    [ATTR_IDX_AUTH] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_AUTH_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_WRITE, MAX_PASSWORD_LENGTH + 1, 0, NULL}
    },

    /* Device Name Characteristic - Read/Write */
    [ATTR_IDX_DEVICE_NAME] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_DEVICE_NAME_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ | ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_READ | ATT_PERM_WRITE, MAX_DEVICE_NAME_LENGTH + 1, 0, (uint8_t*)g_device_name_value}
    },

    /* Mode Control Characteristic */
    [ATTR_IDX_MODE_CONTROL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_MODE_CONTROL_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ | ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_READ | ATT_PERM_WRITE, sizeof(uint8_t), 0, &g_mode_value}
    },

    /* Message Characteristic */
    [ATTR_IDX_MESSAGE] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_MESSAGE_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ | ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_READ | ATT_PERM_WRITE, MAX_MESSAGE_LENGTH + 1, 0, (uint8_t*)g_message_value}
    },

    /* Config Characteristic */
    [ATTR_IDX_CONFIG] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_CONFIG_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_WRITE, sizeof(ConfigCommand), 0, NULL}
    },

    /* Status Characteristic */
    [ATTR_IDX_STATUS] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_STATUS_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, 0, 0},
        {ATT_PERM_READ, sizeof(DeviceStatus), 0, (uint8_t*)&g_status_value}
    },
    [ATTR_IDX_STATUS_CCCD] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ | ATT_PERM_WRITE, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ | ATT_PERM_WRITE, sizeof(uint16_t), 0, NULL}
    },

    /* Promo Text Characteristic */
    [ATTR_IDX_PROMO_TEXT] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_PROMO_TEXT_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ | ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_READ | ATT_PERM_WRITE, MAX_PROMO_TEXT_LENGTH + 1, 0, (uint8_t*)g_promo_text_value}
    },

    /* Stats Characteristic - Read/Notify */
    [ATTR_IDX_STATS] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_STATS_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, 0, 0},
        {ATT_PERM_READ, sizeof(g_stats_buffer), 0, (uint8_t*)g_stats_buffer}
    },
    [ATTR_IDX_STATS_CCCD] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ | ATT_PERM_WRITE, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ | ATT_PERM_WRITE, sizeof(uint16_t), 0, NULL}
    },

    /* Sessions Characteristic - Read Only */
    [ATTR_IDX_SESSIONS] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_SESSIONS_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, 0, 0},
        {ATT_PERM_READ, sizeof(g_sessions_buffer), 0, g_sessions_buffer}
    },

    /* Session Control Characteristic - Write Only */
    [ATTR_IDX_SESSION_CTRL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_SESSION_CTRL_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_WRITE, 16, 0, NULL}
    },

    /* Portal Data Characteristic - Write Only (for chunked data transfer) */
    [ATTR_IDX_PORTAL_DATA] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_PORTAL_DATA_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_WRITE, 200, 0, NULL}  /* Max 200 bytes per chunk */
    },

    /* Portal Control Characteristic - Read/Write/Notify (for commands and status) */
    [ATTR_IDX_PORTAL_CTRL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ, 0, 0, NULL}
    },
    [ATTR_IDX_PORTAL_CTRL_VAL] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ | ATT_PERM_WRITE, 0, 0},
        {ATT_PERM_READ | ATT_PERM_WRITE, 20, 0, NULL}
    },
    [ATTR_IDX_PORTAL_CTRL_CCCD] = {
        ESP_GATT_AUTO_RSP,
        {ATT_PERM_READ | ATT_PERM_WRITE, sizeof(uint16_t), (uint8_t*)&GATT_CHAR_UUID},
        {ATT_PERM_READ | ATT_PERM_WRITE, sizeof(uint16_t), 0, NULL}
    },
};

/* Advertising parameters */
static esp_ble_adv_params_t g_adv_params = {
    .adv_int_min = 0x20,
    .adv_int_max = 0x40,
    .adv_type = ADV_TYPE_IND,
    .own_addr_type = BLE_ADDR_TYPE_PUBLIC,
    .channel_map = ADV_CHNL_ALL,
    .adv_filter_policy = ADV_FILTER_ALLOW_SCAN_ANY_CON_ANY,
};

/**
 * Build advertising data with service UUID
 */
static void build_advertising_data(void)
{
    size_t pos = 0;

    /* Flags: General Discoverable, BR/EDR not supported */
    g_adv_data[pos++] = 0x02;
    g_adv_data[pos++] = 0x01;
    g_adv_data[pos++] = 0x06;

    /* Complete list of 128-bit service UUIDs */
    g_adv_data[pos++] = 0x07;
    g_adv_data[pos++] = 0x06;
    memcpy(&g_adv_data[pos], PROMO_SERVICE_UUID128, 16);
    pos += 16;

    /* Local name - use device name */
    const char* name = g_device_name_value;
    size_t name_len = strlen(name);
    if (name_len > 0) {
        g_adv_data[pos++] = name_len + 1;
        g_adv_data[pos++] = 0x09;
        memcpy(&g_adv_data[pos], name, name_len);
        pos += name_len;
    }

    g_adv_data_len = pos;
    ESP_LOGI(TAG, "Advertising data built, %d bytes", g_adv_data_len);
}

/**
 * Build scan response data with mode info
 */
static void build_scan_response_data(uint8_t* buffer, size_t* length)
{
    size_t pos = 0;

    /* TX power level */
    buffer[pos++] = 0x02;
    buffer[pos++] = 0x0A;
    buffer[pos++] = g_beacon_tx_power;

    /* Manufacturer data with mode info */
    buffer[pos++] = 0x04;
    buffer[pos++] = 0xFF;
    buffer[pos++] = 0xFF;
    buffer[pos++] = 0xFF;
    buffer[pos++] = g_current_mode;

    *length = pos;
}

/**
 * Update status structure
 */
static void update_status_structure(void)
{
    memset(&g_status_value, 0, sizeof(DeviceStatus));

    g_status_value.mode = g_current_mode;
    g_status_value.is_advertising = true;
    g_status_value.is_connected = (g_conn_state == CONN_STATE_CONNECTED);
    g_status_value.uptime_ms = (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);
    g_status_value.rssi = g_current_rssi;
    g_status_value.client_count = g_client_count;
    g_status_value.wifi_clients = (g_current_mode == MODE_G) ? get_client_count() : 0;

    strncpy(g_status_value.message, g_message_value, MAX_MESSAGE_LENGTH);
    g_status_value.message[MAX_MESSAGE_LENGTH] = '\0';

    strncpy(g_status_value.promo_text, g_promo_text_value, MAX_PROMO_TEXT_LENGTH);
    g_status_value.promo_text[MAX_PROMO_TEXT_LENGTH] = '\0';

    /* Add firmware version */
    strncpy(g_status_value.firmware_version, get_firmware_version(), 15);
    g_status_value.firmware_version[15] = '\0';

    /* Add OTA progress */
    ota_progress_t ota_progress;
    ota_get_progress(&ota_progress);
    g_status_value.ota_progress = ota_progress.progress_percent;

    /* Add device ID */
    get_device_id(g_status_value.device_id, MAX_DEVICE_ID_LENGTH);
}

/**
 * Send status notification to connected clients
 */
static void send_status_notification(void)
{
    if (g_handle_status_cccd == 0 || g_conn_state != CONN_STATE_CONNECTED) {
        return;
    }

    update_status_structure();

    esp_ble_gatts_send_indicate(
        g_gatts_if,
        g_conn_id,
        g_handle_status_val,
        sizeof(DeviceStatus),
        (uint8_t*)&g_status_value,
        false
    );
}

/**
 * Status update timer callback
 */
static void status_timer_callback(TimerHandle_t timer)
{
    if (g_conn_state == CONN_STATE_CONNECTED) {
        update_status_structure();

        esp_ble_gatts_set_attr_value(g_handle_status_val, sizeof(DeviceStatus), 
                                     (uint8_t*)&g_status_value);

        esp_ble_gatts_send_indicate(
            g_gatts_if,
            g_conn_id,
            g_handle_status_val,
            sizeof(DeviceStatus),
            (uint8_t*)&g_status_value,
            false
        );
    }
}

/**
 * Load configuration from NVS
 */
static esp_err_t load_config_from_nvs(void)
{
    nvs_handle_t nvs_handle;
    esp_err_t ret;

    ret = nvs_open(BLE_NVS_NAMESPACE, NVS_READONLY, &nvs_handle);
    if (ret != ESP_OK) {
        return ble_reset_defaults();
    }

    /* Load message */
    size_t len = sizeof(g_message_value);
    ret = nvs_get_str(nvs_handle, BLE_NVS_MESSAGE, g_message_value, &len);
    if (ret != ESP_OK || g_message_value[0] == '\0') {
        strcpy(g_message_value, "VISITE-NOS");
    }

    /* Load promo text */
    len = sizeof(g_promo_text_value);
    ret = nvs_get_str(nvs_handle, BLE_NVS_PROMO_TEXT, g_promo_text_value, &len);
    if (ret != ESP_OK || g_promo_text_value[0] == '\0') {
        strcpy(g_promo_text_value, "PROMO-BEACON");
    }

    /* Load beacon params (kept for compatibility) */
    int32_t value;
    ret = nvs_get_i32(nvs_handle, BLE_NVS_MAJOR, &value);
    g_beacon_major = (ret == ESP_OK) ? (uint16_t)value : 1;

    ret = nvs_get_i32(nvs_handle, BLE_NVS_MINOR, &value);
    g_beacon_minor = (ret == ESP_OK) ? (uint16_t)value : 1;

    ret = nvs_get_i32(nvs_handle, BLE_NVS_TX_POWER, &value);
    g_beacon_tx_power = (ret == ESP_OK) ? (int8_t)value : -59;

    nvs_close(nvs_handle);

    ESP_LOGI(TAG, "Config loaded from NVS");

    return ESP_OK;
}

/**
 * Save configuration to NVS
 */
static esp_err_t save_config_to_nvs(void)
{
    nvs_handle_t nvs_handle;
    esp_err_t ret;

    ret = nvs_open(BLE_NVS_NAMESPACE, NVS_READWRITE, &nvs_handle);
    if (ret != ESP_OK) {
        return ret;
    }

    ret = nvs_set_str(nvs_handle, BLE_NVS_MESSAGE, g_message_value);
    if (ret != ESP_OK) { nvs_close(nvs_handle); return ret; }

    ret = nvs_set_str(nvs_handle, BLE_NVS_PROMO_TEXT, g_promo_text_value);
    if (ret != ESP_OK) { nvs_close(nvs_handle); return ret; }

    ret = nvs_set_i32(nvs_handle, BLE_NVS_MAJOR, g_beacon_major);
    if (ret != ESP_OK) { nvs_close(nvs_handle); return ret; }

    ret = nvs_set_i32(nvs_handle, BLE_NVS_MINOR, g_beacon_minor);
    if (ret != ESP_OK) { nvs_close(nvs_handle); return ret; }

    ret = nvs_set_i32(nvs_handle, BLE_NVS_TX_POWER, g_beacon_tx_power);
    if (ret != ESP_OK) { nvs_close(nvs_handle); return ret; }

    ret = nvs_commit(nvs_handle);
    nvs_close(nvs_handle);

    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "Config saved to NVS");
    }

    return ret;
}

/**
 * @brief Switch to G mode
 * 
 * Since this is G-mode only firmware, this function ensures
 * the device is running in G mode configuration.
 */
static esp_err_t ensure_g_mode(void)
{
    ESP_LOGI(TAG, "Ensuring G mode configuration");
    
    /* G mode is always active, nothing to switch to */
    /* Just update advertising data in case device name changed */
    build_advertising_data();
    esp_ble_gap_config_adv_data_raw(g_adv_data, g_adv_data_len);
    
    /* Update and notify status */
    update_status_structure();
    send_status_notification();
    
    return ESP_OK;
}

    ESP_LOGI(TAG, "Mode switch complete: %d", new_mode);

    return ESP_OK;
}

/* GAP event handler */
static void gap_event_handler(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t* param)
{
    switch (event) {
        case ESP_GAP_BLE_ADV_DATA_SET_COMPLETE_EVT:
            ESP_LOGI(TAG, "Advertising data set complete");
            esp_ble_gap_start_advertising(&g_adv_params);
            break;

        case ESP_GAP_BLE_ADV_START_COMPLETE_EVT:
            if (param->adv_start_cmpl.status == ESP_BT_STATUS_SUCCESS) {
                ESP_LOGI(TAG, "Advertising started");
                g_status_value.is_advertising = true;
            } else {
                ESP_LOGE(TAG, "Advertising start failed");
            }
            break;

        case ESP_GAP_BLE_ADV_STOP_COMPLETE_EVT:
            ESP_LOGI(TAG, "Advertising stopped");
            g_status_value.is_advertising = false;
            break;

        case ESP_GAP_BLE_UPDATE_CONN_PARAMS_EVT:
            ESP_LOGI(TAG, "Connection params updated");
            break;

        case ESP_GAP_BLE_PASSKEY_REQ_EVT:
            ESP_LOGI(TAG, "Passkey request received");
            /* Passkey will be set via static passkey security param */
            break;

        case ESP_GAP_BLE_NC_REQ_EVT:
            ESP_LOGI(TAG, "Numeric comparison request");
            /* Just Works pairing - no action needed */
            break;

        case ESP_GAP_BLE_SEC_REQ_EVT:
            ESP_LOGI(TAG, "Security request received");
            /* Accept the security request */
            esp_ble_gap_security_grant(param->sec_req.bd_addr, ESP_BT_STATUS_SUCCESS);
            break;

        case ESP_GAP_BLE_AUTH_CMPL_EVT:
            ESP_LOGI(TAG, "Authentication complete - success: %d",
                     param->auth_cmpl.success);
            if (param->auth_cmpl.success) {
                ESP_LOGI(TAG, "Bonded with device: %02X:**:**:**:%02X:%02X",
                         param->auth_cmpl.bd_addr[0], param->auth_cmpl.bd_addr[4], 
                         param->auth_cmpl.bd_addr[5]);
            } else {
                ESP_LOGW(TAG, "Authentication failed - status: %d", 
                         param->auth_cmpl.fail_reason);
            }
            break;

        case ESP_GAP_BLE_KEY_EVT:
            ESP_LOGI(TAG, "Key event - key type: %d", param->key.key_type);
            break;

        case ESP_GAP_BLE_REMOVE_BOND_DEV_COMPLETE_EVT:
            ESP_LOGI(TAG, "Bond device removed: %02X:**:**:**:**:**",
                     param->remove_bond_dev_cmpl.bd_addr[0]);
            break;

        default:
            break;
    }
}

/* GATT server event handler */
static void gatts_event_handler(esp_gatts_cb_event_t event, esp_gatts_cb_param_t* param)
{
    switch (event) {
        case ESP_GATTS_REG_EVT:
            ESP_LOGI(TAG, "GATT registered, app_id=%d", param->reg.app_id);
            g_gatts_if = param->reg.gatts_if;
            esp_ble_gatts_create_attr_tab(gatt_db, g_gatts_if, ATTR_IDX_TOTAL, 0);
            break;

        case ESP_GATTS_CREATE_EVT:
            ESP_LOGI(TAG, "Service created, handle=%d", param->create.service_id);
            break;

        case ESP_GATTS_ADD_CHAR_EVT: {
            uint16_t uuid16 = param->add_char.char_uuid.uuid.uuid16;
            ESP_LOGI(TAG, "Characteristic added: handle=%d, uuid=%04x",
                     param->add_char.attr_handle, uuid16);

            if (uuid16 == 0x5679) {
                g_handle_mode_control = param->add_char.attr_handle;
                g_handle_mode_control_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x567A) {
                g_handle_message = param->add_char.attr_handle;
                g_handle_message_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x567B) {
                g_handle_config = param->add_char.attr_handle;
                g_handle_config_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x567C) {
                g_handle_status = param->add_char.attr_handle;
                g_handle_status_val = param->add_char.attr_handle + 1;
                g_handle_status_cccd = param->add_char.attr_handle + 2;
            } else if (uuid16 == 0x567D) {
                g_handle_promo_text = param->add_char.attr_handle;
                g_handle_promo_text_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x567E) {
                g_handle_stats = param->add_char.attr_handle;
                g_handle_stats_val = param->add_char.attr_handle + 1;
                g_handle_stats_cccd = param->add_char.attr_handle + 2;
                /* Update stats buffer on first read */
                ble_get_session_stats(g_stats_buffer, sizeof(g_stats_buffer));
            } else if (uuid16 == 0x567F) {
                g_handle_sessions = param->add_char.attr_handle;
                g_handle_sessions_val = param->add_char.attr_handle + 1;
                /* Prepare sessions buffer for first read */
                g_sessions_buffer_len = tracker_serialize_for_ble(
                    g_sessions_buffer, sizeof(g_sessions_buffer), 0, 5);
            } else if (uuid16 == 0x5680) {
                g_handle_session_ctrl = param->add_char.attr_handle;
                g_handle_session_ctrl_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x5681) {
                g_handle_portal_data = param->add_char.attr_handle;
                g_handle_portal_data_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x5682) {
                g_handle_portal_ctrl = param->add_char.attr_handle;
                g_handle_portal_ctrl_val = param->add_char.attr_handle + 1;
                g_handle_portal_ctrl_cccd = param->add_char.attr_handle + 2;
            } else if (uuid16 == 0x5683) {
                g_handle_auth = param->add_char.attr_handle;
                g_handle_auth_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x5684) {
                g_handle_device_name = param->add_char.attr_handle;
                g_handle_device_name_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x5679) {
                g_handle_mode_control = param->add_char.attr_handle;
                g_handle_mode_control_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x567A) {
                g_handle_message = param->add_char.attr_handle;
                g_handle_message_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x567B) {
                g_handle_config = param->add_char.attr_handle;
                g_handle_config_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x567C) {
                g_handle_status = param->add_char.attr_handle;
                g_handle_status_val = param->add_char.attr_handle + 1;
                g_handle_status_cccd = param->add_char.attr_handle + 2;
            } else if (uuid16 == 0x567D) {
                g_handle_promo_text = param->add_char.attr_handle;
                g_handle_promo_text_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x567E) {
                g_handle_stats = param->add_char.attr_handle;
                g_handle_stats_val = param->add_char.attr_handle + 1;
                g_handle_stats_cccd = param->add_char.attr_handle + 2;
                /* Update stats buffer on first read */
                ble_get_session_stats(g_stats_buffer, sizeof(g_stats_buffer));
            } else if (uuid16 == 0x567F) {
                g_handle_sessions = param->add_char.attr_handle;
                g_handle_sessions_val = param->add_char.attr_handle + 1;
                /* Prepare sessions buffer for first read */
                g_sessions_buffer_len = tracker_serialize_for_ble(
                    g_sessions_buffer, sizeof(g_sessions_buffer), 0, 5);
            } else if (uuid16 == 0x5680) {
                g_handle_session_ctrl = param->add_char.attr_handle;
                g_handle_session_ctrl_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x5681) {
                g_handle_portal_data = param->add_char.attr_handle;
                g_handle_portal_data_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x5682) {
                g_handle_portal_ctrl = param->add_char.attr_handle;
                g_handle_portal_ctrl_val = param->add_char.attr_handle + 1;
                g_handle_portal_ctrl_cccd = param->add_char.attr_handle + 2;
            } else if (uuid16 == 0x5683) {
                g_handle_auth = param->add_char.attr_handle;
                g_handle_auth_val = param->add_char.attr_handle + 1;
            } else if (uuid16 == 0x5684) {
                g_handle_device_name = param->add_char.attr_handle;
                g_handle_device_name_val = param->add_char.attr_handle + 1;
            }
            break;
        }

        case ESP_GATTS_CONNECT_EVT:
            ESP_LOGI(TAG, "Client connected, conn_id=%d", param->connect.conn_id);
            g_conn_id = param->connect.conn_id;
            g_conn_state = CONN_STATE_CONNECTED;
            g_client_count++;
            g_status_value.is_connected = true;
            g_status_value.client_count = g_client_count;
            /* Reset authentication state on connect - require re-authentication */
            g_is_authenticated = false;
            g_auth_fail_count = 0;
            break;

        case ESP_GATTS_DISCONNECT_EVT:
            ESP_LOGI(TAG, "Client disconnected, conn_id=%d, reason=0x%x",
                     param->disconnect.conn_id, param->disconnect.reason);
            g_conn_state = CONN_STATE_DISCONNECTED;
            if (g_client_count > 0) g_client_count--;
            g_status_value.is_connected = false;
            g_status_value.client_count = g_client_count;
            /* Reset authentication state on disconnect */
            g_is_authenticated = false;
            break;

        case ESP_GATTS_READ_EVT:
            if (param->read.handle == g_handle_status_val) {
                update_status_structure();
                esp_ble_gatts_set_attr_value(g_handle_status_val, sizeof(DeviceStatus),
                                             (uint8_t*)&g_status_value);
            }
            /* Handle stats characteristic read */
            if (param->read.handle == g_handle_stats_val) {
                ble_get_session_stats(g_stats_buffer, sizeof(g_stats_buffer));
                uint16_t len = strlen(g_stats_buffer);
                esp_ble_gatts_set_attr_value(g_handle_stats_val, len, (uint8_t*)g_stats_buffer);
            }
            /* Handle sessions characteristic read */
            if (param->read.handle == g_handle_sessions_val) {
                /* Refresh sessions buffer */
                g_sessions_buffer_len = tracker_serialize_for_ble(
                    g_sessions_buffer, sizeof(g_sessions_buffer), 0, 5);
                esp_ble_gatts_set_attr_value(g_handle_sessions_val, 
                                             g_sessions_buffer_len, g_sessions_buffer);
            }
            break;

        case ESP_GATTS_WRITE_EVT:
            /* Handle authentication characteristic - password submission */
            if (param->write.handle == g_handle_auth_val && param->write.len > 0) {
                char password[MAX_PASSWORD_LENGTH + 1];
                size_t len = param->write.len;
                if (len > MAX_PASSWORD_LENGTH) len = MAX_PASSWORD_LENGTH;
                memset(password, 0, sizeof(password));
                memcpy(password, param->write.value, len);
                
                ESP_LOGI(TAG, "Authentication attempt received");
                
                if (verify_admin_password(password)) {
                    g_is_authenticated = true;
                    g_auth_fail_count = 0;
                    ESP_LOGI(TAG, "Authentication successful");
                } else {
                    g_is_authenticated = false;
                    g_auth_fail_count++;
                    ESP_LOGW(TAG, "Authentication failed (attempt %lu)", (unsigned long)g_auth_fail_count);
                    
                    /* Lock out after too many failed attempts */
                    if (g_auth_fail_count >= 5) {
                        ESP_LOGE(TAG, "Too many auth failures, disconnecting");
                        esp_ble_gap_disconnect(param->write.conn_handle);
                    }
                }
            }

            /* Handle device name characteristic */
            if (param->write.handle == g_handle_device_name_val && param->write.len > 0) {
                /* Device name changes don't require authentication */
                size_t len = param->write.len;
                if (len > MAX_DEVICE_NAME_LENGTH) len = MAX_DEVICE_NAME_LENGTH;
                memset(g_device_name_value, 0, sizeof(g_device_name_value));
                memcpy(g_device_name_value, param->write.value, len);
                save_config_to_nvs();
                
                /* Update BLE advertising name */
                update_ble_advertising_name(g_device_name_value);
                build_advertising_data();
                esp_ble_gap_config_adv_data_raw(g_adv_data, g_adv_data_len);
                
                ESP_LOGI(TAG, "Device name updated: %s", g_device_name_value);
            }

            /* Check authentication for protected operations */
            if (!g_is_authenticated && is_admin_password_set()) {
                ESP_LOGW(TAG, "Write rejected - not authenticated");
                /* Allow mode control commands even without auth for basic operations */
                if (param->write.handle != g_handle_mode_control_val) {
                    /* Skip all other writes */
                    goto skip_write;
                }
            }

            if (param->write.handle == g_handle_mode_control_val && param->write.len > 0) {
                uint8_t new_mode = param->write.value[0];
                if (new_mode == CMD_MODE_G) {
                    ensure_g_mode();
                    g_mode_value = new_mode;
                    esp_ble_gatts_set_attr_value(g_handle_mode_control_val, sizeof(g_mode_value),
                                                 &g_mode_value);
                } else if (new_mode == CMD_REBOOT) {
                    esp_restart();
                } else if (new_mode == CMD_RESET_DEFAULTS) {
                    ble_reset_defaults();
                    ensure_g_mode();
                }
            }

            if (param->write.handle == g_handle_message_val && param->write.len > 0) {
                size_t len = param->write.len;
                if (len > MAX_MESSAGE_LENGTH) len = MAX_MESSAGE_LENGTH;
                memset(g_message_value, 0, sizeof(g_message_value));
                memcpy(g_message_value, param->write.value, len);
                save_config_to_nvs();
            }

            if (param->write.handle == g_handle_config_val && param->write.len >= 5) {
                ConfigCommand* cmd = (ConfigCommand*)param->write.value;

                if (cmd->command == CONFIG_SET_BEACON_PARAMS) {
                    g_beacon_major = cmd->param1;
                    g_beacon_minor = cmd->param2;
                    g_beacon_tx_power = cmd->param3;
                    save_config_to_nvs();
                }

                if (cmd->command == CONFIG_START_OTA) {
                    ESP_LOGI(TAG, "OTA update requested via BLE");
                    esp_err_t ret = ota_begin();
                    if (ret == ESP_OK) {
                        ESP_LOGI(TAG, "OTA mode activated - firmware upload via /update endpoint");
                    } else {
                        ESP_LOGE(TAG, "Failed to start OTA: %s", esp_err_to_name(ret));
                    }
                }

                if (cmd->command == CONFIG_GET_OTA_STATUS) {
                    /* Status will be read from status characteristic */
                    ESP_LOGI(TAG, "OTA status requested");
                }
            }

            if (param->write.handle == g_handle_promo_text_val && param->write.len > 0) {
                size_t len = param->write.len;
                if (len > MAX_PROMO_TEXT_LENGTH) len = MAX_PROMO_TEXT_LENGTH;
                memset(g_promo_text_value, 0, sizeof(g_promo_text_value));
                memcpy(g_promo_text_value, param->write.value, len);
                save_config_to_nvs();

                update_ble_advertising_name(g_promo_text_value);
                build_advertising_data();
                esp_ble_gap_config_adv_data_raw(g_adv_data, g_adv_data_len);

                /* Update SSID for G mode */
                g_mode_update_ssid(g_promo_text_value);
            }

            /* Handle session control commands */
            if (param->write.handle == g_handle_session_ctrl_val && param->write.len > 0) {
                uint8_t cmd = param->write.value[0];
                
                ESP_LOGI(TAG, "Session control command: 0x%02X", cmd);
                
                if (cmd == SESSION_CMD_CLEAR_ALL) {
                    /* Clear all session history */
                    tracker_clear_all();
                    ESP_LOGI(TAG, "Session history cleared via BLE");
                } else if (cmd == SESSION_CMD_GET_STATS) {
                    /* Update stats buffer for next read */
                    ble_get_session_stats(g_stats_buffer, sizeof(g_stats_buffer));
                } else if (cmd == SESSION_CMD_GET_LATEST) {
                    /* Refresh sessions buffer for next read */
                    uint8_t count = (param->write.len > 1) ? param->write.value[1] : 5;
                    if (count > 10) count = 10;  /* Limit to 10 sessions max */
                    g_sessions_buffer_len = tracker_serialize_for_ble(
                        g_sessions_buffer, sizeof(g_sessions_buffer), 0, count);
                }
            }

            /* Handle portal data characteristic - chunked data transfer */
            if (param->write.handle == g_handle_portal_data_val && param->write.len > 0) {
                /* Data format: [Seq Num: 2 bytes] [Data: up to 200 bytes] */
                if (param->write.len < 2) {
                    ESP_LOGE(TAG, "Invalid portal data chunk: too short");
                } else {
                    uint16_t seq_num = (param->write.value[0] << 8) | param->write.value[1];
                    uint16_t data_len = param->write.len - 2;
                    
                    ESP_LOGD(TAG, "Portal data chunk: seq=%u, len=%u", seq_num, data_len);
                    
                    esp_err_t ret = ble_portal_process_chunk(seq_num, 
                        &param->write.value[2], data_len);
                    if (ret != ESP_OK) {
                        ESP_LOGE(TAG, "Failed to process portal chunk: %s", 
                                 esp_err_to_name(ret));
                    }
                }
            }

            /* Handle portal control characteristic - commands and status */
            if (param->write.handle == g_handle_portal_ctrl_val && param->write.len > 0) {
                uint8_t cmd = param->write.value[0];
                
                ESP_LOGI(TAG, "Portal control command: 0x%02X", cmd);
                
                if (cmd == PORTAL_CMD_START) {
                    /* Format: [CMD=0x10] [Total Size: 4 bytes] [CRC32: 4 bytes] */
                    if (param->write.len >= 9) {
                        uint32_t total_size = 
                            ((uint32_t)param->write.value[1] << 24) |
                            ((uint32_t)param->write.value[2] << 16) |
                            ((uint32_t)param->write.value[3] << 8) |
                            param->write.value[4];
                        uint32_t crc32 = 
                            ((uint32_t)param->write.value[5] << 24) |
                            ((uint32_t)param->write.value[6] << 16) |
                            ((uint32_t)param->write.value[7] << 8) |
                            param->write.value[8];
                        
                        ESP_LOGI(TAG, "Portal upload start: size=%lu, crc=0x%08X",
                                 (unsigned long)total_size, crc32);
                        
                        esp_err_t ret = ble_portal_start_transfer(total_size, crc32);
                        if (ret != ESP_OK) {
                            ESP_LOGE(TAG, "Failed to start portal transfer");
                        }
                        ble_portal_notify_status();
                    }
                } else if (cmd == PORTAL_CMD_END) {
                    ESP_LOGI(TAG, "Portal upload end");
                    esp_err_t ret = ble_portal_complete_transfer();
                    ble_portal_notify_status();
                    /* Notify web server to reload content */
                    if (ret == ESP_OK) {
                        ESP_LOGI(TAG, "Portal content updated, notifying web server");
                    }
                } else if (cmd == PORTAL_CMD_ABORT) {
                    ESP_LOGI(TAG, "Portal upload abort");
                    ble_portal_abort_transfer();
                    ble_portal_notify_status();
                } else if (cmd == PORTAL_CMD_STATUS) {
                    /* Just notify current status */
                    ble_portal_notify_status();
                } else if (cmd == PORTAL_CMD_RESET) {
                    ESP_LOGI(TAG, "Portal reset to default");
                    ble_portal_reset_to_default();
                    ble_portal_notify_status();
                }
            }

            if (param->write.handle == g_handle_status_cccd) {
                uint16_t value = (param->write.value[1] << 8) | param->write.value[0];
                ESP_LOGI(TAG, "CCCD write: 0x%04X", value);
            }
            
        skip_write:
            break;

        case ESP_GATTS_CONF_EVT:
            break;

        case ESP_GATTS_MTU_EVT:
            ESP_LOGI(TAG, "MTU: %d", param->mtu.mtu);
            break;

        default:
            break;
    }
}

/* Public API Implementation */

esp_err_t init_ble_manager(void)
{
    esp_err_t ret;

    if (g_initialized) {
        ESP_LOGW(TAG, "BLE manager already initialized");
        return ESP_OK;
    }

    ESP_LOGI(TAG, "Initializing BLE manager (Unified GATT Service)");

    ret = load_config_from_nvs();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to load config");
        return ret;
    }

    ret = esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "BT memory release failed: %s", esp_err_to_name(ret));
    }

    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_DEFAULT();
    ret = esp_bt_controller_init(&bt_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "BT controller init failed: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_bt_controller_enable(ESP_BT_MODE_BLE);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "BT controller enable failed: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_bluedroid_init();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Bluedroid init failed: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_bluedroid_enable();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Bluedroid enable failed: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_ble_gap_register_callback(gap_event_handler);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "GAP callback register failed: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_ble_gatts_register_callback(gatts_event_handler);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "GATT callback register failed: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = esp_ble_gap_set_device_name(g_promo_text_value);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "Device name set failed: %s", esp_err_to_name(ret));
    }

    build_advertising_data();
    ret = esp_ble_gap_config_adv_data_raw(g_adv_data, g_adv_data_len);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Advertising data config failed: %s", esp_err_to_name(ret));
        return ret;
    }

    uint8_t scan_rsp[64];
    size_t scan_rsp_len;
    build_scan_response_data(scan_rsp, &scan_rsp_len);
    ret = esp_ble_gap_config_scan_rsp_data_raw(scan_rsp, scan_rsp_len);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "Scan response config failed: %s", esp_err_to_name(ret));
    }

    ret = esp_ble_gatts_app_register(0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "GATT app register failed: %s", esp_err_to_name(ret));
        return ret;
    }

    g_status_timer = xTimerCreate("ble_status", pdMS_TO_TICKS(1000),
                                   pdTRUE, NULL, status_timer_callback);
    if (g_status_timer) {
        xTimerStart(g_status_timer, 0);
    }

    g_initialized = true;

    ESP_LOGI(TAG, "Starting G mode");
    init_g_mode();

    ESP_LOGI(TAG, "BLE manager initialized successfully");
    ESP_LOGI(TAG, "Free heap: %lu bytes", esp_get_free_heap_size());

    return ESP_OK;
}

void deinit_ble_manager(void)
{
    if (!g_initialized) {
        return;
    }

    ESP_LOGI(TAG, "Deinitializing BLE manager");

    if (g_status_timer) {
        xTimerStop(g_status_timer, 0);
        xTimerDelete(g_status_timer, 0);
        g_status_timer = NULL;
    }

    esp_ble_gap_stop_advertising();
    cleanup_g_mode();
    esp_bluedroid_disable();
    esp_bluedroid_deinit();
    esp_bt_controller_disable();
    esp_bt_controller_deinit();

    g_initialized = false;
    g_conn_state = CONN_STATE_DISCONNECTED;

    ESP_LOGI(TAG, "BLE manager deinitialized");
}

DeviceMode get_device_mode(void)
{
    return g_current_mode;
}

bool is_ble_connected(void)
{
    return g_conn_state == CONN_STATE_CONNECTED;
}

ConnectionState get_connection_state(void)
{
    return g_conn_state;
}

uint8_t get_ble_client_count(void)
{
    return g_client_count;
}

esp_err_t ble_set_message(const char* message)
{
    if (!message) return ESP_ERR_INVALID_ARG;

    size_t len = strlen(message);
    if (len > MAX_MESSAGE_LENGTH) len = MAX_MESSAGE_LENGTH;

    memset(g_message_value, 0, sizeof(g_message_value));
    strncpy(g_message_value, message, len);

    esp_err_t ret = save_config_to_nvs();
    if (ret != ESP_OK) return ret;


    esp_ble_gatts_set_attr_value(g_handle_message_val, len + 1, 
                                 (uint8_t*)g_message_value);

    return ESP_OK;
}

esp_err_t ble_get_message(char* buffer, size_t buffer_size)
{
    if (!buffer || buffer_size == 0) return ESP_ERR_INVALID_ARG;

    size_t len = strlen(g_message_value);
    if (len >= buffer_size) len = buffer_size - 1;

    memcpy(buffer, g_message_value, len);
    buffer[len] = '\0';

    return ESP_OK;
}

esp_err_t ble_set_promo_text(const char* text)
{
    if (!text) return ESP_ERR_INVALID_ARG;

    size_t len = strlen(text);
    if (len > MAX_PROMO_TEXT_LENGTH) len = MAX_PROMO_TEXT_LENGTH;

    memset(g_promo_text_value, 0, sizeof(g_promo_text_value));
    strncpy(g_promo_text_value, text, len);

    esp_err_t ret = save_config_to_nvs();
    if (ret != ESP_OK) return ret;

    ret = update_ble_advertising_name(g_promo_text_value);
    if (ret != ESP_OK) return ret;

    build_advertising_data();
    return esp_ble_gap_config_adv_data_raw(g_adv_data, g_adv_data_len);
}

esp_err_t ble_get_promo_text(char* buffer, size_t buffer_size)
{
    if (!buffer || buffer_size == 0) return ESP_ERR_INVALID_ARG;

    size_t len = strlen(g_promo_text_value);
    if (len >= buffer_size) len = buffer_size - 1;

    memcpy(buffer, g_promo_text_value, len);
    buffer[len] = '\0';

    return ESP_OK;
}

esp_err_t ble_set_beacon_params(uint16_t major, uint16_t minor, int8_t tx_power)
{
    if (major == 0 || minor == 0) return ESP_ERR_INVALID_ARG;
    if (tx_power < -40 || tx_power > 3) return ESP_ERR_INVALID_ARG;

    g_beacon_major = major;
    g_beacon_minor = minor;
    g_beacon_tx_power = tx_power;

    esp_err_t ret = save_config_to_nvs();
    if (ret != ESP_OK) return ret;


    return ESP_OK;
}

void ble_update_status(const DeviceStatus* status)
{
    if (!status) return;

    g_status_value = *status;
    g_current_rssi = status->rssi;

    esp_ble_gatts_set_attr_value(g_handle_status_val, sizeof(DeviceStatus),
                                 (uint8_t*)&g_status_value);
    send_status_notification();
}

void ble_register_mode_change_callback(mode_change_callback_t callback)
{
    g_mode_change_callback = callback;
}

void ble_register_status_callback(status_update_callback_t callback)
{
    g_status_update_callback = callback;
}

esp_err_t ble_get_status(DeviceStatus* status)
{
    if (!status) return ESP_ERR_INVALID_ARG;

    update_status_structure();
    *status = g_status_value;

    return ESP_OK;
}

void ble_notify_clients(void)
{
    send_status_notification();
}

esp_err_t update_ble_advertising_name(const char* name)
{
    if (!name) return ESP_ERR_INVALID_ARG;

    return esp_bt_dev_set_device_name(name);
}

bool is_g_mode_active(void)
{
    return true;  /* G mode only firmware */
}

esp_err_t ble_reset_defaults(void)
{
    strcpy(g_message_value, "VISITE-NOS");
    strcpy(g_promo_text_value, "PROMO-BEACON");
    strcpy(g_device_name_value, "PROMO-BEACON");
    g_beacon_major = 1;
    g_beacon_minor = 1;
    g_beacon_tx_power = -59;
    g_current_mode = MODE_G;
    g_is_authenticated = false;
    
    return save_config_to_nvs();
}

esp_err_t ble_get_rssi(int8_t* rssi)
{
    if (!rssi) return ESP_ERR_INVALID_ARG;

    *rssi = g_current_rssi;
    return ESP_OK;
}

esp_err_t ble_start_ota_update(void)
{
    ESP_LOGI(TAG, "Starting OTA update via BLE command");
    return ota_begin();
}

esp_err_t ble_get_ota_status(uint8_t* progress, char* status_text, size_t text_size)
{
    if (!progress || !status_text) return ESP_ERR_INVALID_ARG;

    ota_progress_t ota_progress;
    ota_get_progress(&ota_progress);

    *progress = ota_progress.progress_percent;

    /* Get human-readable status */
    ota_get_status_string(status_text, text_size);

    return ESP_OK;
}

/* Session tracking API */

esp_err_t ble_get_session_stats(char* stats_buffer, size_t buffer_size)
{
    if (!stats_buffer || buffer_size == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    tracker_stats_t stats;
    tracker_get_stats(&stats);

    /* Format compact statistics string */
    snprintf(stats_buffer, buffer_size,
             "T:%lu U:%lu A:%lu C:%lu D:%.1f R:%lu",
             (unsigned long)stats.total_connections,
             (unsigned long)stats.total_unique_clients,
             (unsigned long)stats.active_sessions,
             (unsigned long)stats.completed_sessions,
             stats.average_session_duration,
             (unsigned long)stats.total_requests);

    return ESP_OK;
}

uint16_t ble_get_session_data(uint8_t* buffer, size_t buffer_size, uint16_t start_index, uint8_t max_entries)
{
    if (!buffer || buffer_size == 0) {
        return 0;
    }

    return tracker_serialize_for_ble(buffer, buffer_size, start_index, max_entries);
}

uint32_t ble_get_session_history_size(void)
{
    return tracker_get_ble_data_size();
}

esp_err_t ble_clear_session_history(void)
{
    tracker_clear_all();
    ESP_LOGI(TAG, "Session history cleared via BLE API");
    return ESP_OK;
}

/* ============================================================================
 * DEVICE NAME AND AUTHENTICATION MANAGEMENT
 * ============================================================================ */

/**
 * @brief Set device name for BLE advertising
 */
esp_err_t ble_set_device_name(const char* name)
{
    if (!name) return ESP_ERR_INVALID_ARG;

    size_t len = strlen(name);
    if (len > MAX_DEVICE_NAME_LENGTH) len = MAX_DEVICE_NAME_LENGTH;

    memset(g_device_name_value, 0, sizeof(g_device_name_value));
    strncpy(g_device_name_value, name, len);

    esp_err_t ret = save_config_to_nvs();
    if (ret != ESP_OK) return ret;

    ret = update_ble_advertising_name(g_device_name_value);
    if (ret != ESP_OK) return ret;

    build_advertising_data();
    return esp_ble_gap_config_adv_data_raw(g_adv_data, g_adv_data_len);
}

/**
 * @brief Get current device name
 */
esp_err_t ble_get_device_name(char* buffer, size_t buffer_size)
{
    if (!buffer || buffer_size == 0) return ESP_ERR_INVALID_ARG;

    size_t len = strlen(g_device_name_value);
    if (len >= buffer_size) len = buffer_size - 1;

    memcpy(buffer, g_device_name_value, len);
    buffer[len] = '\0';

    return ESP_OK;
}

/**
 * @brief Set admin password for authentication
 */
esp_err_t ble_set_admin_password(const char* password)
{
    nvs_handle_t handle;
    esp_err_t ret;
    
    ret = nvs_open(CONFIG_NAMESPACE, NVS_READWRITE, &handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "NVS open failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    if (password && strlen(password) >= MIN_ADMIN_PASSWORD_LENGTH) {
        ret = nvs_set_str(handle, KEY_ADMIN_PASSWORD, password);
    } else {
        ret = nvs_erase_key(handle, KEY_ADMIN_PASSWORD);
    }
    
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "NVS write failed: %s", esp_err_to_name(ret));
        nvs_close(handle);
        return ret;
    }
    
    ret = nvs_commit(handle);
    nvs_close(handle);
    
    if (ret == ESP_OK) {
        if (password && strlen(password) >= MIN_ADMIN_PASSWORD_LENGTH) {
            strncpy(current_config.admin_password, password, MAX_PASSWORD_LENGTH);
            current_config.admin_password[MAX_PASSWORD_LENGTH] = '\0';
        } else {
            current_config.admin_password[0] = '\0';
        }
        ESP_LOGI(TAG, "Admin password %s", 
                 password && strlen(password) >= MIN_ADMIN_PASSWORD_LENGTH ? "enabled" : "disabled");
        
        /* Reset authentication state when password changes */
        g_is_authenticated = false;
    }
    
    return ret;
}

/**
 * @brief Check if authentication is required
 */
bool ble_is_authentication_required(void)
{
    return is_admin_password_set();
}

/**
 * @brief Check if current session is authenticated
 */
bool ble_is_authenticated(void)
{
    return g_is_authenticated;
}

/**
 * @brief Submit password for authentication
 */
esp_err_t ble_authenticate(const char* password)
{
    if (!password) {
        return ESP_ERR_INVALID_ARG;
    }
    
    if (verify_admin_password(password)) {
        g_is_authenticated = true;
        g_auth_fail_count = 0;
        ESP_LOGI(TAG, "Authentication successful");
        return ESP_OK;
    } else {
        g_is_authenticated = false;
        g_auth_fail_count++;
        ESP_LOGW(TAG, "Authentication failed (attempt %lu)", (unsigned long)g_auth_fail_count);
        
        /* Lock out after too many failed attempts */
        if (g_auth_fail_count >= 5) {
            ESP_LOGE(TAG, "Too many auth failures");
            return ESP_ERR_INVALID_STATE;
        }
        
        return ESP_ERR_INVALID_PASSWORD;
    }
}

/**
 * @brief Clear authentication state
 */
void ble_clear_authentication(void)
{
    g_is_authenticated = false;
    g_auth_fail_count = 0;
}

/* ============================================================================
 * PORTAL CONTENT MANAGEMENT
 * ============================================================================ */

esp_err_t ble_portal_start_transfer(uint32_t total_size, uint32_t crc32)
{
    return portal_transfer_start(total_size, crc32);
}

esp_err_t ble_portal_process_chunk(uint16_t seq_num, const uint8_t* data, uint16_t data_len)
{
    return portal_transfer_process_chunk(seq_num, data_len, data_len);
}

esp_err_t ble_portal_complete_transfer(void)
{
    esp_err_t ret = portal_transfer_complete();
    
    /* If successful, update web server with new content */
    if (ret == ESP_OK) {
        const char* content = portal_content_get();
        size_t size = portal_content_get_size();
        if (content && size > 0) {
            set_portal_content(content, size);
        }
    }
    
    return ret;
}

void ble_portal_abort_transfer(void)
{
    portal_transfer_abort();
}

esp_err_t ble_portal_get_status(uint8_t* status, uint8_t* progress)
{
    return portal_transfer_get_status(status, progress);
}

esp_err_t ble_portal_reset_to_default(void)
{
    esp_err_t ret = portal_reset_to_default();
    
    /* Update web server with default content */
    if (ret == ESP_OK) {
        const char* promo = g_promo_text_value;
        const char* content = portal_get_default_html(promo);
        set_portal_content(content, strlen(content));
    }
    
    return ret;
}

void ble_portal_notify_status(void)
{
    if (g_handle_portal_ctrl_cccd == 0 || g_conn_state != CONN_STATE_CONNECTED) {
        return;
    }

    uint8_t status;
    uint8_t progress;
    ble_portal_get_status(&status, &progress);

    /* Status response format: [Status:1] [Progress:1] [Content Size:4] */
    uint8_t response[6];
    response[0] = status;
    response[1] = progress;
    
    portal_content_info_t info;
    portal_get_info(&info);
    
    response[2] = (info.size >> 24) & 0xFF;
    response[3] = (info.size >> 16) & 0xFF;
    response[4] = (info.size >> 8) & 0xFF;
    response[5] = info.size & 0xFF;

    esp_ble_gatts_send_indicate(
        g_gatts_if,
        g_conn_id,
        g_handle_portal_ctrl_val,
        sizeof(response),
        response,
        false
    );
    
    ESP_LOGD(TAG, "Portal status notified: status=%u, progress=%u%%", status, progress);
}

/* ============================================================================
 * BLE SECURITY IMPLEMENTATION
 * ============================================================================ */

/**
 * @brief Enable BLE security with passkey pairing
 */
esp_err_t ble_enable_security(const char* passkey)
{
    esp_err_t ret;

    if (g_initialized) {
        ESP_LOGW(TAG, "Cannot enable security while BLE is initialized");
        return ESP_ERR_INVALID_STATE;
    }

    /* Set up security parameters */
    esp_ble_io_cap_t iocap = ESP_IO_CAP_NONE;  /* No input, No display - use Just Works */
    
    ret = esp_ble_gap_set_security_param(ESP_BLE_SM_IOCAP_MODE, &iocap, sizeof(iocap));
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set IO cap: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Set authentication requirements - require bonding and MITM */
    uint8_t auth_req = ESP_BLE_SM_AUTHEN_REQ_BOND_MITM;
    ret = esp_ble_gap_set_security_param(ESP_BLE_SM_AUTHEN_REQ, &auth_req, sizeof(auth_req));
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set auth req: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Set minimum key size */
    uint8_t key_size = 16;  /* 16 bytes = 128 bits */
    ret = esp_ble_gap_set_security_param(ESP_BLE_SM_MAX_KEY_SIZE, &key_size, sizeof(key_size));
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set key size: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Set or generate passkey */
    if (passkey && strlen(passkey) == 6) {
        strncpy(g_passkey, passkey, 6);
        g_passkey[6] = '\0';
    } else {
        ret = ble_generate_passkey(g_passkey, sizeof(g_passkey));
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Failed to generate passkey");
            return ret;
        }
    }

    /* Set the passkey for pairing */
    uint32_t passkey_int = atoi(g_passkey);
    ret = esp_ble_gap_set_security_param(ESP_BLE_SM_SET_STATIC_PASSKEY, &passkey_int, sizeof(passkey_int));
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set static passkey: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Register security callback */
    ret = esp_ble_gap_register_callback(security_gap_event_handler);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Security GAP callback register failed: %s", esp_err_to_name(ret));
        return ret;
    }

    g_security_enabled = true;
    ESP_LOGI(TAG, "BLE security enabled with passkey: %s", g_passkey);

    return ESP_OK;
}

/**
 * @brief Disable BLE security
 */
esp_err_t ble_disable_security(void)
{
    if (!g_security_enabled) {
        return ESP_OK;
    }

    g_security_enabled = false;
    ESP_LOGI(TAG, "BLE security disabled");

    return ESP_OK;
}

/**
 * @brief Check if BLE security is enabled
 */
bool ble_is_security_enabled(void)
{
    return g_security_enabled;
}

/**
 * @brief Get current passkey for pairing
 */
esp_err_t ble_get_passkey(char* buffer, size_t buffer_size)
{
    if (!buffer || buffer_size < 7) {
        return ESP_ERR_INVALID_ARG;
    }

    if (!g_security_enabled) {
        return ESP_ERR_INVALID_STATE;
    }

    strncpy(buffer, g_passkey, buffer_size - 1);
    buffer[buffer_size - 1] = '\0';

    return ESP_OK;
}

/**
 * @brief Generate a new random passkey
 */
esp_err_t ble_generate_passkey(char* buffer, size_t buffer_size)
{
    if (!buffer || buffer_size < 7) {
        return ESP_ERR_INVALID_ARG;
    }

    /* Generate random 6-digit passkey */
    uint32_t passkey;
    esp_err_t ret = esp_fill_random(&passkey, sizeof(passkey));
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to generate random passkey");
        return ret;
    }

    /* Ensure it's exactly 6 digits (000000-999999) */
    passkey = passkey % 1000000;

    snprintf(buffer, buffer_size, "%06lu", passkey);
    buffer[6] = '\0';

    ESP_LOGI(TAG, "Generated new passkey: %s", buffer);

    return ESP_OK;
}

/**
 * @brief Set a specific passkey for pairing
 */
esp_err_t ble_set_passkey(const char* passkey)
{
    if (!passkey || strlen(passkey) != 6) {
        return ESP_ERR_INVALID_ARG;
    }

    /* Validate all characters are digits */
    for (int i = 0; i < 6; i++) {
        if (passkey[i] < '0' || passkey[i] > '9') {
            return ESP_ERR_INVALID_ARG;
        }
    }

    strncpy(g_passkey, passkey, 6);
    g_passkey[6] = '\0';

    /* Update passkey in security params if security is enabled */
    if (g_security_enabled) {
        uint32_t passkey_int = atoi(g_passkey);
        esp_ble_gap_set_security_param(ESP_BLE_SM_SET_STATIC_PASSKEY, &passkey_int, sizeof(passkey_int));
    }

    ESP_LOGI(TAG, "Passkey set to: %s", g_passkey);

    return ESP_OK;
}

/**
 * @brief Check if device is bonded with a peer
 */
bool ble_is_bonded(void)
{
    int dev_num = esp_ble_get_bond_device_num();
    if (dev_num < 0) {
        return false;
    }
    return dev_num > 0;
}

/**
 * @brief Remove all bonded devices
 */
esp_err_t ble_remove_bonding(void)
{
    int dev_num = esp_ble_get_bond_device_num();
    if (dev_num < 0) {
        return ESP_ERR_INVALID_STATE;
    }

    esp_ble_bond_dev_t* dev_list = (esp_ble_bond_dev_t*)malloc(sizeof(esp_ble_bond_dev_t) * dev_num);
    if (!dev_list) {
        return ESP_ERR_NO_MEM;
    }

    esp_ble_get_bond_device_num();
    esp_ble_get_bond_device_list(&dev_num, dev_list);

    for (int i = 0; i < dev_num; i++) {
        esp_ble_remove_bond_device(dev_list[i].bd_addr);
    }

    free(dev_list);

    ESP_LOGI(TAG, "Removed %d bonded devices", dev_num);

    return ESP_OK;
}

/**
 * @brief Authenticate using the auth token
 */
esp_err_t ble_authenticate_with_token(const char* token)
{
    if (!token) {
        g_auth_fail_count++;
        g_auth_status = AUTH_STATUS_FAILED;
        return ESP_ERR_INVALID_ARG;
    }

    /* Check if token matches */
    if (verify_auth_token(token)) {
        g_is_authenticated = true;
        g_auth_fail_count = 0;
        g_auth_status = AUTH_STATUS_SUCCESS;
        ESP_LOGI(TAG, "Authentication successful");
        
        /* Notify authentication success */
        if (g_handle_auth_status_cccd != 0 && g_conn_state == CONN_STATE_CONNECTED) {
            uint8_t response[1] = {AUTH_STATUS_SUCCESS};
            esp_ble_gatts_send_indicate(
                g_gatts_if,
                g_conn_id,
                g_handle_auth_status_val,
                sizeof(response),
                response,
                false
            );
        }
        
        return ESP_OK;
    } else {
        g_auth_fail_count++;
        g_auth_status = AUTH_STATUS_FAILED;
        
        /* Lock device after too many failures */
        if (g_auth_fail_count >= 5) {
            g_auth_status = AUTH_STATUS_LOCKED;
            ESP_LOGE(TAG, "Too many auth failures - device locked");
            return ESP_ERR_INVALID_STATE;
        }
        
        ESP_LOGW(TAG, "Authentication failed (attempt %lu)", g_auth_fail_count);
        
        /* Notify authentication failure */
        if (g_handle_auth_status_cccd != 0 && g_conn_state == CONN_STATE_CONNECTED) {
            uint8_t response[1] = {AUTH_STATUS_FAILED};
            esp_ble_gatts_send_indicate(
                g_gatts_if,
                g_conn_id,
                g_handle_auth_status_val,
                sizeof(response),
                response,
                false
            );
        }
        
        return ESP_ERR_INVALID_PASSWORD;
    }
}

/**
 * @brief Get authentication status
 */
esp_err_t ble_get_auth_status(uint8_t* status)
{
    if (!status) {
        return ESP_ERR_INVALID_ARG;
    }
    
    *status = g_auth_status;
    return ESP_OK;
}

/**
 * @brief Get auth token hint (first 4 characters)
 */
esp_err_t ble_get_token_hint(char* buffer, size_t buffer_size)
{
    if (!buffer || buffer_size < 5) {
        return ESP_ERR_INVALID_ARG;
    }

    char token[AUTH_TOKEN_LENGTH * 2 + 1];
    esp_err_t ret = load_auth_token(token, sizeof(token));
    if (ret != ESP_OK || token[0] == '\0') {
        strncpy(buffer, "----", buffer_size - 1);
        buffer[buffer_size - 1] = '\0';
        return ESP_ERR_NOT_FOUND;
    }

    /* Return first 4 characters as hint */
    strncpy(buffer, token, 4);
    buffer[4] = '\0';

    return ESP_OK;
}

/**
 * @brief Check if client is authenticated
 */
bool ble_is_client_authenticated(void)
{
    return g_is_authenticated;
}
