/**
 * OTA Update Implementation
 *
 * Provides Over-The-Air firmware update functionality
 * with automatic data preservation.
 *
 * Key Features:
 * - Preserves all NVS configuration automatically (NVS is separate partition)
 * - Web-based firmware update via /update endpoint
 * - BLE-triggered update initiation
 * - Automatic rollback on failure
 * - Version management and validation
 *
 * Author: MiniMax Agent
 * Version: 2.0.0
 */

#include "ota_update.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_ota_ops.h"
#include "esp_partition.h"
#include "esp_image_format.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "string.h"
#include "stdio.h"

static const char* TAG = "OTA_UPDATE";

/* NVS Keys for OTA data */
#define OTA_NVS_NAMESPACE           "ota_data"
#define OTA_NVS_LAST_VERSION        "last_version"
#define OTA_NVS_UPDATE_COUNT        "update_count"
#define OTA_NVS_FIRST_BOOT          "first_boot"

/* Local static variables */
static ota_progress_t g_progress = {0};
static ota_config_t g_config = {0};
static const esp_partition_t* g_running_partition = NULL;
static const esp_partition_t* g_ota_partition = NULL;
static esp_ota_handle_t g_ota_handle = 0;
static bool g_ota_initialized = false;

/**
 * @brief Get string for OTA status
 */
static const char* status_to_string(ota_status_t status)
{
    switch (status) {
        case OTA_STATUS_IDLE: return "Idle";
        case OTA_STATUS_IN_PROGRESS: return "In Progress";
        case OTA_STATUS_SUCCESS: return "Success";
        case OTA_STATUS_FAILED: return "Failed";
        case OTA_STATUS_ROLLBACK: return "Rollback";
        case OTA_STATUS_CHECKING: return "Checking";
        case OTA_STATUS_DOWNLOADING: return "Downloading";
        default: return "Unknown";
    }
}

/**
 * @brief Initialize OTA subsystem
 */
void ota_init(void)
{
    if (g_ota_initialized) {
        ESP_LOGW(TAG, "OTA already initialized");
        return;
    }

    ESP_LOGI(TAG, "Initializing OTA subsystem");
    ESP_LOGI(TAG, "Firmware Version: %s", FIRMWARE_VERSION);

    /* Load OTA configuration */
    g_config.auto_check_updates = false;
    g_config.check_interval_hours = 24;
    g_config.auto_rollback = true;
    g_config.update_url[0] = '\0';

    /* Check if this is first boot after OTA update */
    ota_check_first_boot();

    /* Get running partition info */
    g_running_partition = esp_ota_get_running_partition();
    if (g_running_partition) {
        ESP_LOGI(TAG, "Running partition: %s at offset 0x%x",
                 g_running_partition->label, g_running_partition->address);
    }

    /* Reset progress */
    memset(&g_progress, 0, sizeof(g_progress));
    g_progress.status = OTA_STATUS_IDLE;

    g_ota_initialized = true;
    ESP_LOGI(TAG, "OTA subsystem initialized");
}

/**
 * @brief Check if this is first boot after OTA update
 */
static void ota_check_first_boot(void)
{
    nvs_handle_t nvs_handle;
    esp_err_t ret;

    ret = nvs_open(OTA_NVS_NAMESPACE, NVS_READONLY, &nvs_handle);
    if (ret != ESP_OK) {
        /* First boot ever - initialize NVS */
        nvs_open(OTA_NVS_NAMESPACE, NVS_READWRITE, &nvs_handle);
        nvs_set_u8(nvs_handle, OTA_NVS_FIRST_BOOT, 1);
        nvs_commit(nvs_handle);
        nvs_close(nvs_handle);
        ESP_LOGI(TAG, "First boot - initializing OTA data");
        return;
    }

    uint8_t first_boot = 0;
    ret = nvs_get_u8(nvs_handle, OTA_NVS_FIRST_BOOT, &first_boot);
    if (ret == ESP_OK && first_boot == 0) {
        /* This is first boot after OTA update */
        ESP_LOGI(TAG, "First boot after OTA update");

        /* Increment update count */
        uint32_t update_count = 0;
        nvs_get_u32(nvs_handle, OTA_NVS_UPDATE_COUNT, &update_count);
        update_count++;
        nvs_set_u32(nvs_handle, OTA_NVS_UPDATE_COUNT, update_count);

        /* Store previous version */
        char last_version[32] = {0};
        size_t len = sizeof(last_version);
        ret = nvs_get_str(nvs_handle, OTA_NVS_LAST_VERSION, last_version, &len);
        if (ret == ESP_OK) {
            ESP_LOGI(TAG, "Previous version: %s", last_version);
        }

        /* Update to current version */
        nvs_set_str(nvs_handle, OTA_NVS_LAST_VERSION, FIRMWARE_VERSION);
        nvs_commit(nvs_handle);

        /* Verify NVS data integrity */
        ota_verify_nvs_integrity();
    }

    nvs_close(nvs_handle);
}

/**
 * @brief Verify NVS data integrity after OTA
 */
static void ota_verify_nvs_integrity(void)
{
    nvs_handle_t nvs_handle;
    esp_err_t ret;

    /* Check that critical configuration keys exist */
    ret = nvs_open("config", NVS_READONLY, &nvs_handle);
    if (ret == ESP_OK) {
        char ssid[32] = {0};
        size_t len = sizeof(ssid);
        ret = nvs_get_str(nvs_handle, "ssid", ssid, &len);
        if (ret == ESP_OK) {
            ESP_LOGI(TAG, "NVS integrity verified - SSID preserved: %s", ssid);
        } else {
            ESP_LOGW(TAG, "NVS SSID not found - may be first boot");
        }
        nvs_close(nvs_handle);
    }
}

/**
 * @brief Begin OTA update process
 *
 * Prepares the next OTA partition for writing.
 *
 * @return ESP_OK on success, error code otherwise
 */
esp_err_t ota_begin(void)
{
    if (g_progress.status == OTA_STATUS_IN_PROGRESS) {
        ESP_LOGE(TAG, "OTA already in progress");
        return ESP_ERR_INVALID_STATE;
    }

    /* Get next OTA partition */
    g_ota_partition = esp_ota_get_next_update_partition(NULL);
    if (!g_ota_partition) {
        ESP_LOGE(TAG, "No OTA partition found");
        return ESP_ERR_NOT_FOUND;
    }

    ESP_LOGI(TAG, "Starting OTA - target partition: %s at offset 0x%x",
             g_ota_partition->label, g_ota_partition->address);

    /* Begin OTA update */
    esp_err_t ret = esp_ota_begin(g_ota_partition, OTA_SIZE_UNKNOWN, &g_ota_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_begin failed: %s", esp_err_to_name(ret));
        g_progress.status = OTA_STATUS_FAILED;
        snprintf(g_progress.error_message, sizeof(g_progress.error_message),
                 "OTA begin failed: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Reset progress */
    g_progress.status = OTA_STATUS_IN_PROGRESS;
    g_progress.total_bytes = 0;
    g_progress.written_bytes = 0;
    g_progress.progress_percent = 0;
    g_progress.error_message[0] = '\0';

    ESP_LOGI(TAG, "OTA update started successfully");
    return ESP_OK;
}

/**
 * @brief Write data to OTA partition
 *
 * @param data Pointer to data buffer
 * @param length Length of data in bytes
 * @return ESP_OK on success, error code otherwise
 */
esp_err_t ota_write(const void* data, size_t length)
{
    if (g_progress.status != OTA_STATUS_IN_PROGRESS) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!data || length == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    /* Write data to OTA partition */
    esp_err_t ret = esp_ota_write(g_ota_handle, data, length);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_write failed: %s", esp_err_to_name(ret));
        g_progress.status = OTA_STATUS_FAILED;
        snprintf(g_progress.error_message, sizeof(g_progress.error_message),
                 "OTA write failed: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Update progress */
    g_progress.written_bytes += length;
    if (g_progress.total_bytes > 0) {
        g_progress.progress_percent = (g_progress.written_bytes * 100) / g_progress.total_bytes;
    }

    /* Log progress every 10% */
    if (g_progress.progress_percent % 10 == 0 && g_progress.progress_percent > 0) {
        ESP_LOGI(TAG, "OTA progress: %u%% (%u / %u bytes)",
                 g_progress.progress_percent,
                 g_progress.written_bytes,
                 g_progress.total_bytes);
    }

    return ESP_OK;
}

/**
 * @brief Set total OTA size (optional)
 *
 * Call this before ota_write if total size is known.
 *
 * @param total_bytes Total bytes to be written
 */
void ota_set_total_size(uint32_t total_bytes)
{
    g_progress.total_bytes = total_bytes;
}

/**
 * @brief End OTA update process
 *
 * Validates the written firmware and sets it as bootable.
 *
 * @return ESP_OK on success, error code otherwise
 */
esp_err_t ota_end(void)
{
    if (g_progress.status != OTA_STATUS_IN_PROGRESS) {
        return ESP_ERR_INVALID_STATE;
    }

    ESP_LOGI(TAG, "Completing OTA update...");

    /* Finish OTA */
    esp_err_t ret = esp_ota_end(g_ota_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_end failed: %s", esp_err_to_name(ret));
        g_progress.status = OTA_STATUS_FAILED;
        snprintf(g_progress.error_message, sizeof(g_progress.error_message),
                 "OTA validation failed: %s", esp_err_to_name(ret));

        if (g_config.auto_rollback) {
            ota_rollback();
        }
        return ret;
    }

    /* Set boot partition */
    ret = esp_ota_set_boot_partition(g_ota_partition);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_set_boot_partition failed: %s", esp_err_to_name(ret));
        g_progress.status = OTA_STATUS_FAILED;
        snprintf(g_progress.error_message, sizeof(g_progress.error_message),
                 "Failed to set boot partition: %s", esp_err_to_name(ret));
        return ret;
    }

    g_progress.status = OTA_STATUS_SUCCESS;
    g_progress.progress_percent = 100;
    ESP_LOGI(TAG, "OTA update completed successfully!");
    ESP_LOGI(TAG, "Device will boot to new firmware on next restart");

    return ESP_OK;
}

/**
 * @brief Abort OTA update
 *
 * Cancels the current OTA update and rolls back if needed.
 */
void ota_abort(void)
{
    if (g_progress.status == OTA_STATUS_IN_PROGRESS) {
        esp_ota_abort(g_ota_handle);
        g_progress.status = OTA_STATUS_FAILED;
        ESP_LOGW(TAG, "OTA update aborted");
    }
}

/**
 * @brief Rollback to previous firmware
 *
 * Marks the current firmware as invalid and rolls back to the previous version.
 */
void ota_rollback(void)
{
    ESP_LOGW(TAG, "Initiating rollback to previous firmware...");

    esp_err_t ret = esp_ota_mark_app_invalid_rollback_and_reboot();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Rollback failed: %s", esp_err_to_name(ret));
    }
    /* If this returns, rollback wasn't possible (no previous valid image) */
}

/**
 * @brief Mark current firmware as valid
 *
 * Called after successful boot to prevent automatic rollback.
 */
void ota_mark_valid(void)
{
    esp_err_t ret = esp_ota_mark_app_valid_cancel_rollback();
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "Firmware marked as valid - rollback disabled");
    } else if (ret == ESP_ERR_OTA_VALIDATE_FAILED) {
        ESP_LOGW(TAG, "Firmware validation failed - rollback will occur on next boot");
    } else {
        ESP_LOGW(TAG, "Could not mark firmware as valid: %s", esp_err_to_name(ret));
    }
}

/**
 * @brief Get firmware version string
 */
const char* get_firmware_version(void)
{
    return FIRMWARE_VERSION;
}

/**
 * @brief Get firmware version as integer
 */
uint32_t get_firmware_version_int(void)
{
    return (FIRMWARE_VERSION_MAJOR << 16) |
           (FIRMWARE_VERSION_MINOR << 8) |
           FIRMWARE_VERSION_PATCH;
}

/**
 * @brief Get current OTA progress
 */
void ota_get_progress(ota_progress_t* progress)
{
    if (progress) {
        *progress = g_progress;
    }
}

/**
 * @brief Get OTA configuration
 */
ota_config_t* ota_get_config(void)
{
    return &g_config;
}

/**
 * @brief Set OTA configuration
 */
void ota_set_config(ota_config_t* config)
{
    if (config) {
        g_config = *config;

        /* Save to NVS */
        nvs_handle_t nvs_handle;
        if (nvs_open(OTA_NVS_NAMESPACE, NVS_READWRITE) == ESP_OK) {
            nvs_set_u8(nvs_handle, "auto_check", g_config.auto_check_updates);
            nvs_set_u32(nvs_handle, "check_interval", g_config.check_interval_hours);
            nvs_commit(nvs_handle);
            nvs_close(nvs_handle);
        }
    }
}

/**
 * @brief Check if OTA update is in progress
 */
bool ota_is_in_progress(void)
{
    return g_progress.status == OTA_STATUS_IN_PROGRESS;
}

/**
 * @brief Get last OTA error message
 */
const char* ota_get_last_error(void)
{
    return g_progress.error_message[0] ? g_progress.error_message : "No error";
}

/**
 * @brief Get partition info string
 */
void ota_get_partition_info(char* buffer, size_t buffer_size)
{
    const esp_partition_t* running = esp_ota_get_running_partition();
    const esp_partition_t* boot = esp_ota_get_boot_partition();
    const esp_partition_t* next = esp_ota_get_next_update_partition(NULL);

    snprintf(buffer, buffer_size,
             "Running: %s (0x%x)\n"
             "Boot: %s (0x%x)\n"
             "Next OTA: %s (0x%x)\n"
             "Version: %s",
             running ? running->label : "N/A",
             running ? running->address : 0,
             boot ? boot->label : "N/A",
             boot ? boot->address : 0,
             next ? next->label : "N/A",
             next ? next->address : 0,
             FIRMWARE_VERSION);
}

/**
 * @brief Reset OTA data
 */
void ota_reset(void)
{
    nvs_handle_t nvs_handle;
    if (nvs_open(OTA_NVS_NAMESPACE, NVS_READWRITE) == ESP_OK) {
        nvs_erase_all(nvs_handle);
        nvs_commit(nvs_handle);
        nvs_close(nvs_handle);
    }
    g_progress.status = OTA_STATUS_IDLE;
    ESP_LOGI(TAG, "OTA data reset");
}

/**
 * @brief Check if new firmware is available
 *
 * Currently stub - would check against update server.
 */
bool ota_check_for_updates(void)
{
    /* Stub implementation - would connect to update server
     * and compare versions */
    ESP_LOGI(TAG, "Update check requested");
    g_progress.status = OTA_STATUS_CHECKING;

    /* TODO: Implement actual update checking
     * - Connect to update_url if configured
     * - Compare version with FIRMWARE_VERSION
     * - Return true if update available */

    g_progress.status = OTA_STATUS_IDLE;
    return false;
}

/**
 * @brief Get human-readable OTA status for display
 */
void ota_get_status_string(char* buffer, size_t buffer_size)
{
    ota_progress_t prog;
    ota_get_progress(&prog);

    if (prog.status == OTA_STATUS_IDLE) {
        snprintf(buffer, buffer_size, "Up to date (v%s)", FIRMWARE_VERSION);
    } else if (prog.status == OTA_STATUS_IN_PROGRESS) {
        snprintf(buffer, buffer_size, "Updating: %u%%", prog.progress_percent);
    } else if (prog.status == OTA_STATUS_SUCCESS) {
        snprintf(buffer, buffer_size, "Update complete - reboot required");
    } else if (prog.status == OTA_STATUS_FAILED) {
        snprintf(buffer, buffer_size, "Update failed: %s", prog.error_message);
    } else {
        snprintf(buffer, buffer_size, "%s", status_to_string(prog.status));
    }
}
