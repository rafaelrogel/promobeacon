/**
 * Status Collector Header
 * 
 * Defines the interface for device status monitoring.
 * Tracks connected clients, session duration, portal engagement,
 * and battery level with minimal memory overhead.
 */

#ifndef STATUS_COLLECTOR_H
#define STATUS_COLLECTOR_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Maximum tracked clients */
#define MAX_TRACKED_CLIENTS       6

/**
 * @brief Device status structure (6 bytes for BLE transmission)
 */
typedef struct __attribute__((packed)) {
    uint8_t flags;                    /* Bit0: AP active, Bit1: BLE active, Bits2-7: reserved */
    uint8_t client_count;             /* 0-6 connected clients */
    uint16_t session_duration_sec;    /* Seconds since mode start */
    uint8_t portal_time_avg_sec;      /* Average portal engagement time per client */
    uint8_t battery_percent;          /* 0-100 battery percentage */
} DeviceStatus;

/**
 * @brief Client tracking structure
 */
typedef struct {
    bool active;                      /* Client connection active */
    uint8_t mac[6];                   /* Client MAC address */
    uint32_t connect_time;            /* Connection timestamp (seconds) */
    uint32_t portal_start_time;       /* Portal engagement start timestamp */
} client_info_t;

/**
 * @brief Initialize status collector
 * 
 * Initializes all tracking structures and resets counters.
 */
void init_status_collector(void);

/**
 * @brief Update status
 * 
 * Called periodically to update status fields.
 * Should be called from main loop every ~1 second.
 */
void update_status(void);

/**
 * @brief Serialize status to buffer
 * 
 * Packs the DeviceStatus structure into a 6-byte buffer
 * suitable for BLE transmission.
 * 
 * @param buffer Buffer to receive packed data (6 bytes minimum)
 */
void serialize_status(uint8_t* buffer);

/**
 * @brief Get current status
 * 
 * @return Pointer to current DeviceStatus structure
 */
const DeviceStatus* get_status(void);

/**
 * @brief Notify client connected
 * 
 * Called when a WiFi client connects.
 * 
 * @param mac Client MAC address (6 bytes)
 */
void on_client_connected(const uint8_t* mac);

/**
 * @brief Notify client disconnected
 * 
 * Called when a WiFi client disconnects.
 * Updates portal engagement time tracking.
 * 
 * @param mac Client MAC address (6 bytes)
 */
void on_client_disconnected(const uint8_t* mac);

/**
 * @brief Get session duration in seconds
 * 
 * @return Seconds since current mode started
 */
uint32_t get_session_duration(void);

/**
 * @brief Get average portal engagement time
 * 
 * @return Average seconds clients spend on portal
 */
uint8_t get_portal_engagement_time(void);

/**
 * @brief Get connected client count
 * 
 * @return Number of active client connections
 */
uint8_t get_connected_client_count(void);

/**
 * @brief Force battery update
 * 
 * Immediately reads and updates the battery percentage.
 * Normally called periodically, but can be called on demand.
 * 
 * @return Current battery percentage (0-100)
 */
uint8_t update_battery_percent(void);

#ifdef __cplusplus
}
#endif

#endif /* STATUS_COLLECTOR_H */
